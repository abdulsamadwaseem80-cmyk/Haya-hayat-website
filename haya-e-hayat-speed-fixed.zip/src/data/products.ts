import { resolveImage } from '../utils/images';
export const INSTAGRAM_ORDER_URL = 'https://www.instagram.com/hayaehayat?stkn=MXIwZHJsNngzdWpwYQ==';
export const INSTAGRAM_HANDLE = '@hayaehayat';

export interface ProductColorOption {
  name: string;
  urduName?: string;
  hex: string;
  textColor?: 'light' | 'dark';
  category?: 'Popular' | 'Pastel' | 'Neutral' | 'Jewel Tone';
  description?: string;
}

export const CORDSET_CUSTOM_COLORS: ProductColorOption[] = [
  { name: 'Deep Plum Wine', urduName: 'جامنی بیر', hex: '#4A1D34', textColor: 'light', category: 'Jewel Tone', description: 'Original pearl signature' },
  { name: 'Soft Sage Green', urduName: 'سیج سبز', hex: '#8A9A86', textColor: 'light', category: 'Pastel', description: 'University bestseller' },
  { name: 'Mocha Latte', urduName: 'موکا براؤن', hex: '#8C735D', textColor: 'light', category: 'Neutral', description: 'Workwear favorite neutral' },
  { name: 'Slate Charcoal Grey', urduName: 'سرمئی سلیٹ', hex: '#4A5568', textColor: 'light', category: 'Neutral', description: 'Minimalist everyday' },
  { name: 'Dusty Sky Blue', urduName: 'ہلکا اسمانی', hex: '#6B8E9F', textColor: 'light', category: 'Pastel', description: 'Fresh & breezy' },
  { name: 'Chocolate Espresso', urduName: 'چاکلیٹ کتھئی', hex: '#3D281E', textColor: 'light', category: 'Neutral', description: 'Rich earthy warmth' },
  { name: 'Dusty Rose Mauve', urduName: 'گلابی موو', hex: '#B57D82', textColor: 'light', category: 'Pastel', description: 'Soft feminine grace' },
  { name: 'Terracotta Rust', urduName: 'گیرو رسٹ', hex: '#A65B44', textColor: 'light', category: 'Jewel Tone', description: 'Warm aesthetic tone' },
  { name: 'Midnight Jet Black', urduName: 'سیاہ کوئلہ', hex: '#1C1C1C', textColor: 'light', category: 'Neutral', description: 'Timeless wardrobe staple' },
  { name: 'Pearl Ivory Cream', urduName: 'موتیا کریم', hex: '#F7F4EB', textColor: 'dark', category: 'Neutral', description: 'Clean & pristine' },
  { name: 'Olive Moss Green', urduName: 'زیتونی سبز', hex: '#5B6B38', textColor: 'light', category: 'Jewel Tone', description: 'Classic campus look' },
  { name: 'Lavender Lilac', urduName: 'لیوینڈر لائلک', hex: '#9E8EB8', textColor: 'light', category: 'Pastel', description: 'Dreamy soft pastel' },
];

export interface Product {
  id: string;
  name: string;
  urduName?: string;
  category: 'coord-sets' | 'embroidered-pret' | 'university-edit' | 'festive-wear' | 'casual-cotton';
  categoryLabel: string;
  pricePKR: number;
  originalPricePKR: number;
  rating: number;
  reviewCount: number;
  tag?: string;
  description: string;
  fabric: string;
  cut: string;
  packageContains: string;
  color: string;
  colorHex: string;
  isColorCustomizable?: boolean;
  customColorOptions?: ProductColorOption[];
  availableSizes: ('XS' | 'S' | 'M' | 'L' | 'XL' | 'Custom')[];
  image: string;
  secondaryImage?: string;
  features: string[];
  isBestSeller?: boolean;
  isNewArrival?: boolean;
  isUniversityFavorite?: boolean;
}

export const PRODUCTS: Product[] = [
  {
    id: 'hh-solid-sage',
    name: 'Pistachio Sage 2-Piece Tassel & Pearl Co-ord Set',
    urduName: 'پستہ سیج ٹو پیس پرل و ٹیسل سیٹ',
    category: 'coord-sets',
    categoryLabel: '2-Piece Co-ord Sets',
    pricePKR: 3250,
    originalPricePKR: 3950,
    rating: 5.0,
    reviewCount: 148,
    tag: 'New Drop · Pistachio Sage 🌿',
    description: 'Fresh pistachio sage green solid 2-piece modest co-ord set with handcrafted split V-neckline adorned with fine silk drop tassel and pearl loop button detailing, matching pearl cuff accents, and tailored wide-leg trousers. Designed for university, office workwear, and effortless modest styling. Delivered with Free Shipping all over Pakistan!',
    fabric: 'Ultra-Soft Wrinkle-Free Crepe Silk Blend',
    cut: 'Straight Modest Tunic with Tailored Wide-Leg Trousers',
    packageContains: 'Pistachio Tassel Tunic + Wide Leg Trouser (2-Piece Set)',
    color: 'Soft Sage Pistachio Green',
    colorHex: '#8A9A86',
    isColorCustomizable: true,
    customColorOptions: CORDSET_CUSTOM_COLORS,
    availableSizes: ['XS', 'S', 'M', 'L', 'XL', 'Custom'],
    image: resolveImage('/src/assets/images/sage_coord_set_1790268404551.jpg'),
    secondaryImage: resolveImage('/src/assets/images/sage_pearl_detail_1790268420183.jpg'),
    features: [
      'Handcrafted silk tassel drop and pearl loop buttons on neckline',
      'Matching dainty pearl buttons on sleeve cuffs',
      'Comfortable relaxed modest silhouette for campus & workwear',
      'Free Delivery all over Pakistan with Cash on Delivery (COD)',
      'Available for custom color & tailored sizing customization'
    ],
    isBestSeller: true,
    isNewArrival: true,
    isUniversityFavorite: true
  },
  {
    id: 'hh-solid-plum',
    name: 'Solid 2-Piece Pearl Flare Plum Co-ord Set',
    urduName: 'جامنی سالڈ ٹو پیس پرل کٹ',
    category: 'coord-sets',
    categoryLabel: '2-Piece Co-ord Sets',
    pricePKR: 3250,
    originalPricePKR: 3950,
    rating: 5.0,
    reviewCount: 168,
    tag: 'Customize in Your Favorite Color✨🫶🏻',
    description: 'customize in your favorite color✨🫶🏻 . . . solid 2-piece, affordable workwear, university girl outfit. Tailored in an elegant modest A-line flared frock silhouette with delicate hand-set faux pearl beadwork lining the square neckline, paired with matching wide-leg flared trousers. Available in any custom color of your choice!',
    fabric: 'Premium Wrinkle-Free Crepe Silk Blend',
    cut: 'A-Line Flared Tunic with Wide-Leg Palazzos',
    packageContains: 'Pearl-Work Tunic + Matching Flared Trouser (2-Piece Set)',
    color: 'Deep Plum Burgundy (Available in Any Favorite Color)',
    colorHex: '#4A1D34',
    isColorCustomizable: true,
    customColorOptions: CORDSET_CUSTOM_COLORS,
    availableSizes: ['XS', 'S', 'M', 'L', 'XL', 'Custom'],
    image: resolveImage('/src/assets/images/plum_coord_set_1790262536094.jpg'),
    secondaryImage: resolveImage('/src/assets/images/plum_pearl_detail_1790262553412.jpg'),
    features: [
      'Customize in ANY favorite color (Sage, Mocha, Slate, Plum, Black & more)',
      'Delicate double-row pearl beaded neckline on pure crepe silk blend',
      'Modest flowy A-line flare with front pleating',
      'Matching wide-leg palazzo trouser for all-day campus & office comfort',
      'Wrinkle-resistant fabric ideal for university & workwear'
    ],
    isBestSeller: true,
    isNewArrival: true,
    isUniversityFavorite: true
  },
  {
    id: 'hh-gota-navy',
    name: 'Noor Navy Gold Gota-Patti Festive 2-Piece',
    urduName: 'نور نیوی گوٹا پٹی سیٹ',
    category: 'festive-wear',
    categoryLabel: 'Festive Wear',
    pricePKR: 3950,
    originalPricePKR: 4800,
    rating: 4.9,
    reviewCount: 94,
    tag: 'Festive Bestseller',
    description: 'A striking royal navy blue flared A-line kurti adorned with gleaming gold gota-patti ribbon paneling, split neck, and border trims. Paired with ivory trousers featuring intricate geometric chevron gota triangles and horizontal borders.',
    fabric: 'Pure Pre-Shrunk Breathable Cambric Cotton',
    cut: 'Flared Kalidar Kurti with Straight Cutwork Trouser',
    packageContains: 'Gota Work Kurti + Embroidered Ivory Trouser (2-Piece Set)',
    color: 'Royal Navy Blue & Ivory',
    colorHex: '#1B365D',
    availableSizes: ['XS', 'S', 'M', 'L', 'XL', 'Custom'],
    image: resolveImage('/src/assets/images/gota_navy_festive_1790262572910.jpg'),
    secondaryImage: resolveImage('/src/assets/images/gota_black_festive_1790262593723.jpg'),
    features: [
      'Gleaming gold gota-patti paneling',
      'Artisanal geometric chevron border on trouser cuffs',
      'Lightweight festive comfort for events & family gatherings',
      'Pre-washed colorfast cambric fabric'
    ],
    isBestSeller: true,
    isNewArrival: true,
    isUniversityFavorite: false
  },
  {
    id: 'hh-gota-black',
    name: 'Siah Zari Gold Gota 2-Piece Festive Ensemble',
    urduName: 'سیاہ زری گوٹا پٹی سیٹ',
    category: 'festive-wear',
    categoryLabel: 'Festive Wear',
    pricePKR: 3950,
    originalPricePKR: 4800,
    rating: 5.0,
    reviewCount: 112,
    tag: 'Signature Piece',
    description: 'Timeless jet black flared A-line frock kurti detailed with metallic gold gota patti along the neckline and vertical flare panels, complemented by ivory trousers with geometric gota embellishments.',
    fabric: 'Fine Cotton Cambric & Metallic Zari Gota',
    cut: 'Flared Frock Tunic with Geometric Hem Trousers',
    packageContains: 'Black Gota Kurti + Off-White Trouser (2-Piece Set)',
    color: 'Midnight Black & Cream',
    colorHex: '#1C1C1C',
    availableSizes: ['XS', 'S', 'M', 'L', 'XL', 'Custom'],
    image: resolveImage('/src/assets/images/gota_black_festive_1790262593723.jpg'),
    secondaryImage: resolveImage('/src/assets/images/gota_pink_festive_1790262610664.jpg'),
    features: [
      'Rich black fabric with contrast gold gota patti',
      'Contrast ivory trousers with triple gota border and triangles',
      'Breathable, modest silhouette suitable for festivities',
      'Tailored with premium CMT precision in Karachi'
    ],
    isBestSeller: true,
    isNewArrival: true,
    isUniversityFavorite: false
  },
  {
    id: 'hh-gota-pink',
    name: 'Gulabi Rooh Silver Gota 2-Piece Pret',
    urduName: 'گلابی روح سلور گوٹا سیٹ',
    category: 'festive-wear',
    categoryLabel: 'Festive Wear',
    pricePKR: 3850,
    originalPricePKR: 4600,
    rating: 4.8,
    reviewCount: 76,
    tag: 'Pastel Festive',
    description: 'Charming pastel baby pink A-line kurti with sparkling silver gota patti ribbon detailing, accompanied by ivory trousers with matching silver geometric triangle motifs.',
    fabric: 'Soft Weave Breathable Lawn Cotton',
    cut: 'A-Line Flared Kurti with Embroidered Trousers',
    packageContains: 'Pink Gota Kurti + Ivory Trouser (2-Piece Set)',
    color: 'Pastel Blush Pink & Cream',
    colorHex: '#EBB4BA',
    availableSizes: ['XS', 'S', 'M', 'L', 'XL', 'Custom'],
    image: resolveImage('/src/assets/images/gota_pink_festive_1790262610664.jpg'),
    secondaryImage: resolveImage('/src/assets/images/gota_navy_festive_1790262572910.jpg'),
    features: [
      'Delicate silver gota patti neckline & panel finish',
      'Subtle pastel feminine hue',
      'Matching silver triangle border on pants',
      'Comfortable lightweight feel for long days'
    ],
    isBestSeller: false,
    isNewArrival: true,
    isUniversityFavorite: true
  },
  {
    id: 'hh-01',
    name: 'Sage Whisper 2-Piece Linen Co-ord',
    urduName: 'سیج وِسپَر ٹو پیس',
    category: 'coord-sets',
    categoryLabel: '2-Piece Co-ord Sets',
    pricePKR: 3850,
    originalPricePKR: 4500,
    rating: 4.9,
    reviewCount: 142,
    tag: 'Best Seller',
    description: 'A breathable washed-linen two-piece co-ord set tailored in an airy relaxed modest silhouette. Features intricate sleeve cuff cutwork embroidery, a relaxed mandarin collar, and tailored straight-fit trousers with deep side pockets.',
    fabric: 'Pure Washed Organic Linen',
    cut: 'Relaxed Modest Cut with Drop Shoulder',
    packageContains: 'Shirt + Straight Trouser (2-Piece Set)',
    color: 'Sage Mist',
    colorHex: '#8A9A86',
    availableSizes: ['XS', 'S', 'M', 'L', 'XL', 'Custom'],
    image: resolveImage('/src/assets/images/hero_modest_fashion_1790260531937.jpg'),
    secondaryImage: resolveImage('/src/assets/images/category_coord_sets_1790260543569.jpg'),
    features: ['Delicate cuff cutwork detailing', 'Deep functional trouser pockets', 'Pre-shrunk breathable linen', 'Mandarin neckline with fabric buttons'],
    isBestSeller: true,
    isNewArrival: false,
    isUniversityFavorite: true
  },
  {
    id: 'hh-02',
    name: 'Blush Blossom Cutwork Cotton Set',
    urduName: 'بلش کٹ ورک سیٹ',
    category: 'coord-sets',
    categoryLabel: '2-Piece Co-ord Sets',
    pricePKR: 3600,
    originalPricePKR: 4200,
    rating: 4.8,
    reviewCount: 98,
    tag: 'Trending',
    description: 'Graceful dusty blush two-piece cord set crafted from soft premium cambric cotton. Decorated with floral cutwork along the hemline and sleeves, offering modest coverage and effortless everyday elegance.',
    fabric: 'Premium 100% Cambric Cotton',
    cut: 'A-Line Modest Tunic with Culotte Trousers',
    packageContains: 'Tunic Shirt + Culotte Pants',
    color: 'Dusty Blush',
    colorHex: '#D8A49B',
    availableSizes: ['XS', 'S', 'M', 'L', 'XL', 'Custom'],
    image: resolveImage('/src/assets/images/category_coord_sets_1790260543569.jpg'),
    secondaryImage: resolveImage('/src/assets/images/hero_modest_fashion_1790260531937.jpg'),
    features: ['Floral laser-cut cutwork hem', 'Soft cotton lining', 'Elasticated comfortable waistband', 'Concealed nursing/everyday placket'],
    isBestSeller: true,
    isNewArrival: true,
    isUniversityFavorite: false
  },
  {
    id: 'hh-03',
    name: 'Azure Pearl Embroidered Pret Kurti',
    urduName: 'آبی پرل کُرتی',
    category: 'embroidered-pret',
    categoryLabel: 'Embroidered Pret',
    pricePKR: 2950,
    originalPricePKR: 3500,
    rating: 4.9,
    reviewCount: 116,
    tag: 'Artisanal Craft',
    description: 'A serene powder-blue modest kurti embellished with delicate ivory threadwork, handcrafted loop buttons, and freshwater pearl accents along the split neck. Pair with your favorite culottes or denim.',
    fabric: 'Fine Slub Raw Silk & Cotton Weave',
    cut: 'Classic Straight Fit with High Slits',
    packageContains: 'Single Pret Kurti Shirt',
    color: 'Powder Azure',
    colorHex: '#9CB7C6',
    availableSizes: ['XS', 'S', 'M', 'L', 'XL', 'Custom'],
    image: resolveImage('/src/assets/images/category_embroidered_pret_1790260557863.jpg'),
    secondaryImage: resolveImage('/src/assets/images/hero_modest_fashion_1790260531937.jpg'),
    features: ['Handcrafted ivory needlework', 'Genuine shell pearl embellishments', 'Flattering modest sleeve length', 'Luxe breathable weave'],
    isBestSeller: false,
    isNewArrival: true,
    isUniversityFavorite: false
  },
  {
    id: 'hh-04',
    name: 'Mocha University Essential Modest Tunic',
    urduName: 'موکا یونیورسٹی ٹیونک',
    category: 'university-edit',
    categoryLabel: 'University Edit',
    pricePKR: 2750,
    originalPricePKR: 3200,
    rating: 5.0,
    reviewCount: 204,
    tag: 'Campus Favorite',
    description: 'Designed specifically for bustling university life. This mocha brown button-down tunic features a modest long silhouette, wrinkle-resistant twill cotton, twin chest utility pockets, and reinforced stitching for daily wear.',
    fabric: 'Heavy Twill Breathable Cotton',
    cut: 'Longline Utility Tunic with Side Vents',
    packageContains: 'Single Modest Utility Tunic',
    color: 'Mocha Cocoa',
    colorHex: '#7C6353',
    availableSizes: ['XS', 'S', 'M', 'L', 'XL', 'Custom'],
    image: resolveImage('/src/assets/images/category_university_edits_1790260569649.jpg'),
    secondaryImage: resolveImage('/src/assets/images/category_coord_sets_1790260543569.jpg'),
    features: ['High durability wrinkle-resistant fabric', 'Deep cargo utility pockets', 'Comfortable roll-up button sleeves', 'Modest knee-length coverage'],
    isBestSeller: true,
    isNewArrival: false,
    isUniversityFavorite: true
  },
  {
    id: 'hh-05',
    name: 'Emerald Zari Festive Two-Piece Ensemble',
    urduName: 'زمرد زری فیسٹیو سیٹ',
    category: 'festive-wear',
    categoryLabel: 'Festive Wear',
    pricePKR: 5400,
    originalPricePKR: 6200,
    rating: 4.9,
    reviewCount: 83,
    tag: 'Festive Edition',
    description: 'An exquisite jewel-toned festive 2-piece outfit in royal emerald green. Accented with subtle golden metallic zari embroidery along the organza borders and cuffs, tailored for Eid, family gatherings, and intimate festivities.',
    fabric: 'Premium Dobby Silk with Tissue Organza Hem',
    cut: 'Flared Angrakha-Inspired Kurta with Cigarette Pants',
    packageContains: 'Embroidered Kurta + Straight Trouser',
    color: 'Royal Emerald',
    colorHex: '#1B4D3E',
    availableSizes: ['XS', 'S', 'M', 'L', 'XL', 'Custom'],
    image: resolveImage('/src/assets/images/category_festive_wear_1790260582134.jpg'),
    secondaryImage: resolveImage('/src/assets/images/category_embroidered_pret_1790260557863.jpg'),
    features: ['Subtle matte gold zari stitching', 'Sheer organza hemline inlays', 'Includes matching tailored trousers', 'Ideal for festive and semi-formal wear'],
    isBestSeller: false,
    isNewArrival: true,
    isUniversityFavorite: false
  },
  {
    id: 'hh-06',
    name: 'Ivory Minimalist Monochrome Co-ord',
    urduName: 'آئیوری مونوکروم ٹو پیس',
    category: 'coord-sets',
    categoryLabel: '2-Piece Co-ord Sets',
    pricePKR: 3450,
    originalPricePKR: 4000,
    rating: 4.8,
    reviewCount: 77,
    tag: 'Wardrobe Staple',
    description: 'Pristine raw ivory monochromatic co-ord set with self-texture slub fabric. Featuring wooden carved buttons, subtle pin-tuck detailing on the bodice, and wide-leg modest trousers for breezy summer days.',
    fabric: 'Textured Slub Lawn Cotton',
    cut: 'Contemporary Boxy Tunic with Wide Trouser',
    packageContains: 'Textured Tunic + Wide Leg Trouser',
    color: 'Warm Ivory',
    colorHex: '#F6F5F0',
    availableSizes: ['XS', 'S', 'M', 'L', 'XL', 'Custom'],
    image: resolveImage('/src/assets/images/category_coord_sets_1790260543569.jpg'),
    secondaryImage: resolveImage('/src/assets/images/hero_modest_fashion_1790260531937.jpg'),
    features: ['Opaque non-see-through fabric finish', 'Natural coconut shell buttons', 'Geometric front pin-tucks', 'Breezy wide-leg cut'],
    isBestSeller: true,
    isNewArrival: false,
    isUniversityFavorite: true
  },
  {
    id: 'hh-07',
    name: 'Terracotta Classic Campus Cord Set',
    urduName: 'ٹیراکوٹا کیمپس سیٹ',
    category: 'university-edit',
    categoryLabel: 'University Edit',
    pricePKR: 3700,
    originalPricePKR: 4300,
    rating: 4.9,
    reviewCount: 165,
    tag: 'University Hit',
    description: 'Rich terracotta rust co-ord set featuring a chic polo collar with modest drop-hem shirt and matching comfortable trousers. A hit among Karachi and Lahore university students for its comfort and modest style.',
    fabric: 'Soft Cotton Khaddar (All-Weather)',
    cut: 'Polo Neck Shirt + Tulip Hem Trouser',
    packageContains: 'Polo Shirt + Trouser (2-Piece)',
    color: 'Terracotta Rust',
    colorHex: '#BD5338',
    availableSizes: ['XS', 'S', 'M', 'L', 'XL', 'Custom'],
    image: resolveImage('/src/assets/images/category_university_edits_1790260569649.jpg'),
    secondaryImage: resolveImage('/src/assets/images/hero_modest_fashion_1790260531937.jpg'),
    features: ['Polo collar with mother-of-pearl buttons', 'Tulip slit trouser ankles', 'Fade-resistant reactive dye', 'Easy wash-and-wear care'],
    isBestSeller: true,
    isNewArrival: false,
    isUniversityFavorite: true
  },
  {
    id: 'hh-08',
    name: 'Lilac Grace Cutwork Slub Shirt',
    urduName: 'لائلک کٹ ورک قمیض',
    category: 'embroidered-pret',
    categoryLabel: 'Embroidered Pret',
    pricePKR: 2850,
    originalPricePKR: 3400,
    rating: 4.7,
    reviewCount: 64,
    tag: 'Limited Batch',
    description: 'Delicate pastel lilac single shirt adorned with geometric thread cutwork along the daaman (hem) and bell sleeves. An elegant staple to pair with white trousers or light wash denim.',
    fabric: 'Breathable Slub Cotton',
    cut: 'Straight Cut with Flared Sleeves',
    packageContains: 'Single Ready-to-Wear Shirt',
    color: 'Pastel Lilac',
    colorHex: '#C8B9D6',
    availableSizes: ['XS', 'S', 'M', 'L', 'XL', 'Custom'],
    image: resolveImage('/src/assets/images/category_embroidered_pret_1790260557863.jpg'),
    secondaryImage: resolveImage('/src/assets/images/category_coord_sets_1790260543569.jpg'),
    features: ['Geometric daaman cutwork border', 'Subtle bell sleeve silhouette', 'Soft hand-feel', 'Pair with any neutral bottom'],
    isBestSeller: false,
    isNewArrival: true,
    isUniversityFavorite: false
  }
];

export interface SizeSpecification {
  size: string;
  chest: string;
  shirtLength: string;
  shoulder: string;
  sleeveLength: string;
  trouserLength: string;
  trouserWaist: string;
  hip: string;
}

export const SIZE_CHART: SizeSpecification[] = [
  { size: 'XS', chest: '36"', shirtLength: '38"', shoulder: '14"', sleeveLength: '21"', trouserLength: '37"', trouserWaist: '26-30"', hip: '38"' },
  { size: 'S',  chest: '38"', shirtLength: '39"', shoulder: '14.5"', sleeveLength: '21.5"', trouserLength: '38"', trouserWaist: '28-34"', hip: '40"' },
  { size: 'M',  chest: '41"', shirtLength: '40"', shoulder: '15"', sleeveLength: '22"', trouserLength: '39"', trouserWaist: '30-38"', hip: '43"' },
  { size: 'L',  chest: '44"', shirtLength: '41"', shoulder: '15.5"', sleeveLength: '22.5"', trouserLength: '40"', trouserWaist: '32-42"', hip: '46"' },
  { size: 'XL', chest: '47"', shirtLength: '42"', shoulder: '16.5"', sleeveLength: '23"', trouserLength: '40.5"', trouserWaist: '34-46"', hip: '50"' }
];

export const INSTAGRAM_HIGHLIGHTS = [
  {
    id: 'ig-sage-tassel',
    handle: '@hayaehayat',
    caption: 'New Drop 🌿 Pistachio Sage Solid 2-Piece with handcrafted pearl buttons and silk tassel drop. Pure comfort for workwear & university! ✨',
    likes: 2450,
    date: 'Just now · Trending',
    image: resolveImage('/src/assets/images/sage_coord_set_1790268404551.jpg')
  },
  {
    id: 'ig-new-solid',
    handle: '@hayaehayat',
    caption: 'customize in your favorite color✨🫶🏻 . . . solid 2-piece, affordable workwear, university girl outfit',
    likes: 1980,
    date: '1 day ago',
    image: resolveImage('/src/assets/images/plum_coord_set_1790262536094.jpg')
  },
  {
    id: 'ig-festive-gota',
    handle: '@hayaehayat',
    caption: 'Festive Gota-Patti Kalidar sets in 4 royal shades (Navy, Jet Black, Blush Pink & Sky Blue) with detailed geometric ivory trousers! ✨',
    likes: 2130,
    date: 'Yesterday',
    image: resolveImage('/src/assets/images/gota_navy_festive_1790262572910.jpg')
  },
  {
    id: 'ig-pearl-detail',
    handle: '@hayaehayat',
    caption: 'Hand-sewn delicate pearl beadwork along the neckline. Designed for daily comfort from 9 to 5. 🤍',
    likes: 1420,
    date: '3 days ago',
    image: resolveImage('/src/assets/images/plum_pearl_detail_1790262553412.jpg')
  },
  {
    id: 'ig-black-gota',
    handle: '@hayaehayat',
    caption: 'The timeless appeal of black & gold zari gota with pure off-white cambric trousers. Modest & regal. 🖤',
    likes: 1780,
    date: '1 week ago',
    image: resolveImage('/src/assets/images/gota_black_festive_1790262593723.jpg')
  }
];

export const BRAND_REVIEWS = [
  {
    id: 'rev-1',
    name: 'Ayesha Tariq',
    city: 'Karachi (IBA Student)',
    rating: 5,
    date: 'Verified Buyer · September 2026',
    comment: 'I ordered the Sage linen 2-piece set for my university classes. The fabric quality is exceptional—so breathable even in Karachi heat! The cutwork detail on the cuffs is gorgeous.',
    productName: 'Sage Whisper 2-Piece Linen Co-ord'
  },
  {
    id: 'rev-2',
    name: 'Zainab Noor',
    city: 'Lahore (DHA Phase 5)',
    rating: 5,
    date: 'Verified Buyer · September 2026',
    comment: 'Requested custom length for both shirt and trouser via WhatsApp. The team was so responsive and got the fitting 100% exact. Cash on delivery arrived within 3 days!',
    productName: 'Custom Stitched Co-ord Set'
  },
  {
    id: 'rev-3',
    name: 'Dr. Mahnoor Khan',
    city: 'Islamabad',
    rating: 5,
    date: 'Verified Buyer · August 2026',
    comment: 'Hard to find modest wear that is both fashionable and decent for hospital duty and consultations. Haya-e-Hayat nailed the balance. Will be ordering more colors.',
    productName: 'Mocha University Essential Modest Tunic'
  }
];
