import React from 'react';
import { Sparkles, Scissors, Shirt, GraduationCap, Award, HelpCircle } from 'lucide-react';

interface CategoryNavStripProps {
  activeCategory: string;
  onSelectCategory: (id: string) => void;
  onOpenSizeGuide: () => void;
}

const CATEGORIES = [
  { id: 'all', label: 'All Designs', icon: Sparkles },
  { id: 'coord-sets', label: '2-Piece Co-ords', icon: Shirt },
  { id: 'embroidered-pret', label: 'Cutwork Embroidered', icon: Scissors },
  { id: 'university-edit', label: 'University Daily Wear', icon: GraduationCap },
  { id: 'festive-wear', label: 'Festive Pret', icon: Award },
];

export const CategoryNavStrip: React.FC<CategoryNavStripProps> = ({
  activeCategory,
  onSelectCategory,
  onOpenSizeGuide,
}) => {
  return (
    <div className="bg-[#F4F1EA] border-b border-stone-200 overflow-x-auto scrollbar-none py-2.5 px-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4 min-w-max text-xs">
        <div className="flex items-center gap-1 sm:gap-2">
          {CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-full font-medium transition-all cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-stone-900 text-stone-50 shadow-sm'
                    : 'text-stone-700 hover:text-stone-900 hover:bg-stone-200/70'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#DDC8AA]' : 'text-stone-500'}`} />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-3 pl-4 border-l border-stone-300">
          <button
            onClick={onOpenSizeGuide}
            className="flex items-center gap-1.5 text-stone-700 hover:text-stone-950 font-medium underline underline-offset-2 transition-colors cursor-pointer"
          >
            <HelpCircle className="w-3.5 h-3.5 text-amber-800" />
            <span>Need Custom Stitching?</span>
          </button>
          <a
            href="https://wa.me/923214292328?text=Hello%20Haya-e-Hayat!%20I%20would%20like%20to%20place%20an%20order"
            target="_blank"
            rel="noopener noreferrer"
            className="px-2.5 py-1 bg-emerald-700 text-white rounded text-[11px] font-semibold hover:bg-emerald-800 transition-colors"
          >
            WhatsApp Help
          </a>
        </div>
      </div>
    </div>
  );
};
