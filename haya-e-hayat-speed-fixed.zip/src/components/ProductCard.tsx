import React, { useState } from 'react';
import { Heart, Eye, ShoppingBag, Check, Instagram, Palette, Sparkles } from 'lucide-react';
import { Product, INSTAGRAM_ORDER_URL, CORDSET_CUSTOM_COLORS, ProductColorOption } from '../data/products';
import { Currency } from '../types';
import { formatPrice } from '../utils/format';
import { handleImageError } from '../utils/images';

interface ProductCardProps {
  product: Product;
  currency: Currency;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onAddToCart: (
    product: Product,
    size: 'XS' | 'S' | 'M' | 'L' | 'XL' | 'Custom',
    customMeasurements?: {
      shirtLength?: string;
      chest?: string;
      trouserLength?: string;
      additionalNote?: string;
    },
    customColor?: {
      name: string;
      hex: string;
      neckline?: string;
      shirtLength?: string;
      trouserStyle?: string;
      isCustomToned?: boolean;
    }
  ) => void;
  onOpenCustomColorStudio?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  currency,
  isWishlisted,
  onToggleWishlist,
  onQuickView,
  onAddToCart,
  onOpenCustomColorStudio,
}) => {
  const [selectedSize, setSelectedSize] = useState<'XS' | 'S' | 'M' | 'L' | 'XL' | 'Custom'>('M');
  const [activeColor, setActiveColor] = useState<ProductColorOption>(
    product.customColorOptions ? product.customColorOptions[0] : { name: product.color, hex: product.colorHex }
  );
  const [showSizePicker, setShowSizePicker] = useState(false);
  const [justAdded, setJustAdded] = useState(false);

  const discountPercent = Math.round(
    ((product.originalPricePKR - product.pricePKR) / product.originalPricePKR) * 100
  );

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    const colorData = product.isColorCustomizable
      ? {
          name: activeColor.name,
          hex: activeColor.hex,
          neckline: 'Double-Row Pearls',
          shirtLength: 'Standard 38"',
          trouserStyle: 'Flared Palazzo',
          isCustomToned: true,
        }
      : undefined;

    onAddToCart(product, selectedSize, undefined, colorData);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1600);
  };

  return (
    <div className="group relative rounded-2xl bg-white border border-stone-200/90 hover:border-stone-300 shadow-xs hover:shadow-md transition-all duration-300 flex flex-col overflow-hidden">
      {/* Visual Image Slot */}
      <div 
        onClick={() => onQuickView(product)}
        className="relative aspect-4/5 w-full overflow-hidden bg-[#F7F5F0] cursor-pointer"
      >
        <img
          src={product.image}
          alt={product.name}
          referrerPolicy="no-referrer"
          loading="lazy"
          decoding="async"
          className="w-full h-full object-cover object-center group-hover:scale-104 transition-transform duration-500"
          onError={handleImageError}
        />

        {/* Dynamic Color Tint when customizable */}
        {product.isColorCustomizable && (
          <>
            <div 
              className="absolute inset-0 mix-blend-color opacity-70 pointer-events-none transition-colors duration-300"
              style={{ backgroundColor: activeColor.hex }}
            />
            <div 
              className="absolute inset-0 mix-blend-multiply opacity-20 pointer-events-none transition-colors duration-300"
              style={{ backgroundColor: activeColor.hex }}
            />
          </>
        )}

        {/* Top Badges / Discount */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 pointer-events-none">
          {product.tag && (
            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 bg-stone-900 text-stone-100 rounded shadow-xs flex items-center gap-1">
              {product.isColorCustomizable && <Sparkles className="w-2.5 h-2.5 text-amber-300" />}
              {product.tag}
            </span>
          )}
          {discountPercent > 0 && (
            <span className="text-[10px] font-bold px-1.5 py-0.5 bg-[#C9533B] text-white rounded w-fit shadow-xs">
              -{discountPercent}%
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product);
          }}
          className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md transition-all cursor-pointer ${
            isWishlisted
              ? 'bg-rose-50 text-rose-600 shadow-sm'
              : 'bg-white/80 text-stone-600 hover:text-stone-900 hover:bg-white'
          }`}
          aria-label={isWishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current text-rose-600' : ''}`} />
        </button>

        {/* Hover Quick Actions Overlay */}
        <div className="absolute inset-x-3 bottom-3 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex gap-2">
          {product.isColorCustomizable && onOpenCustomColorStudio ? (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onOpenCustomColorStudio(product);
              }}
              className="flex-1 py-2 px-3 bg-white/95 hover:bg-white text-stone-900 text-xs font-semibold rounded-lg shadow-sm backdrop-blur-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Palette className="w-3.5 h-3.5 text-rose-700" />
              <span>Customize Color ✨</span>
            </button>
          ) : (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onQuickView(product);
              }}
              className="flex-1 py-2 px-3 bg-white/95 hover:bg-white text-stone-900 text-xs font-semibold rounded-lg shadow-sm backdrop-blur-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Quick View</span>
            </button>
          )}

          <a
            href={INSTAGRAM_ORDER_URL}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => {
              e.stopPropagation();
              if (navigator?.clipboard?.writeText) {
                const colorMsg = product.isColorCustomizable ? ` in color ${activeColor.name}` : '';
                navigator.clipboard.writeText(`Assalam o Alaikum! I would like to order: ${product.name}${colorMsg} (Rs. ${product.pricePKR})`).catch(() => {});
              }
            }}
            className="p-2 bg-gradient-to-tr from-[#833AB4] via-[#FD1D1D] to-[#FCB045] text-white rounded-lg shadow-sm hover:opacity-95 transition-opacity flex items-center justify-center"
            title="DM on Instagram to order this design"
          >
            <Instagram className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

      {/* Product Content Details */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Metadata unboxed text */}
          <div className="flex items-center justify-between text-xs text-stone-500 mb-1.5">
            <span className="uppercase tracking-wider text-[11px] font-medium text-stone-600">
              {product.categoryLabel}
            </span>
            <div className="flex items-center gap-1 text-stone-700">
              <span className="text-amber-500">★</span>
              <span className="font-semibold text-xs tabular-nums">{product.rating}</span>
              <span className="text-stone-400 text-[11px]">({product.reviewCount})</span>
            </div>
          </div>

          {/* Product Name */}
          <h3 
            onClick={() => onQuickView(product)}
            className="font-serif text-base sm:text-lg font-medium text-stone-900 group-hover:text-stone-700 transition-colors line-clamp-1 cursor-pointer"
          >
            {product.name}
          </h3>

          {/* Fabric & Cut highlight */}
          <p className="text-xs text-stone-500 mt-1 line-clamp-1">
            {product.fabric} · {product.cut}
          </p>

          {/* Color Swatches if Customizable */}
          {product.isColorCustomizable && (
            <div className="mt-2.5 pt-2 border-t border-stone-100 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-medium text-stone-500">Colors:</span>
                <div className="flex items-center -space-x-1">
                  {CORDSET_CUSTOM_COLORS.slice(0, 5).map((c) => (
                    <button
                      key={c.name}
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveColor(c);
                      }}
                      title={c.name}
                      className={`w-4 h-4 rounded-full border border-white transition-transform hover:scale-125 cursor-pointer ${
                        activeColor.name === c.name ? 'scale-125 ring-1 ring-stone-900 z-10' : ''
                      }`}
                      style={{ backgroundColor: c.hex }}
                    />
                  ))}
                </div>
                <span className="text-[10px] text-stone-400 font-medium">+7</span>
              </div>

              {onOpenCustomColorStudio && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenCustomColorStudio(product);
                  }}
                  className="text-[10px] font-semibold text-rose-700 hover:text-rose-900 flex items-center gap-0.5 cursor-pointer underline"
                >
                  <span>Customize</span>
                  <Sparkles className="w-2.5 h-2.5" />
                </button>
              )}
            </div>
          )}

          {/* Pricing & Free Delivery Badge */}
          <div className="mt-2.5 flex items-center justify-between gap-2">
            <div className="flex items-baseline gap-2">
              <span className="font-semibold text-base sm:text-lg text-stone-900 tabular-nums">
                {formatPrice(product.pricePKR, currency)}
              </span>
              {product.originalPricePKR > product.pricePKR && (
                <span className="text-xs text-stone-400 line-through tabular-nums">
                  {formatPrice(product.originalPricePKR, currency)}
                </span>
              )}
            </div>
            <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200/70 px-1.5 py-0.5 rounded">
              Free Delivery
            </span>
          </div>
        </div>

        {/* Size Selection & Quick Add */}
        <div className="mt-4 pt-3 border-t border-stone-100">
          <div className="flex items-center justify-between gap-1 mb-2">
            <span className="text-[11px] font-medium text-stone-500">Select Size:</span>
            <div className="flex gap-1">
              {product.availableSizes.slice(0, 4).map((sz) => (
                <button
                  key={sz}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedSize(sz);
                  }}
                  className={`text-[10px] w-5 h-5 rounded flex items-center justify-center font-medium transition-colors ${
                    selectedSize === sz
                      ? 'bg-stone-900 text-stone-100 font-bold'
                      : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                  }`}
                >
                  {sz}
                </button>
              ))}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onQuickView(product);
                }}
                className="text-[10px] text-stone-500 hover:text-stone-900 underline px-1"
                title="More sizes & custom measurements"
              >
                More
              </button>
            </div>
          </div>

          <div className="flex gap-1.5">
            <button
              onClick={handleAdd}
              className={`flex-1 py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                justAdded
                  ? 'bg-emerald-700 text-white'
                  : 'bg-stone-900 hover:bg-stone-800 text-stone-50'
              }`}
            >
              {justAdded ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Added!</span>
                </>
              ) : (
                <>
                  <ShoppingBag className="w-3.5 h-3.5 text-stone-300" />
                  <span>Add ({selectedSize})</span>
                </>
              )}
            </button>

            <a
              href={INSTAGRAM_ORDER_URL}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => {
                e.stopPropagation();
                if (navigator?.clipboard?.writeText) {
                  const colorStr = product.isColorCustomizable ? ` in Color "${activeColor.name}"` : '';
                  navigator.clipboard.writeText(`Assalam o Alaikum Haya-e-Hayat! I want to order "${product.name}"${colorStr} in Size ${selectedSize} (Rs. ${product.pricePKR})`).catch(() => {});
                }
              }}
              className="px-2.5 py-2 rounded-lg bg-pink-50 hover:bg-pink-100 text-pink-700 border border-pink-200/80 transition-colors flex items-center justify-center gap-1 text-[11px] font-semibold cursor-pointer shrink-0"
              title="DM on Instagram to order this design"
            >
              <Instagram className="w-3.5 h-3.5" />
              <span>DM</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
