import React, { useState } from 'react';
import { X, Heart, ShoppingBag, ShieldCheck, Ruler, Truck, MessageCircle, Check, Instagram, Palette, Sparkles } from 'lucide-react';
import { Product, SIZE_CHART, INSTAGRAM_ORDER_URL, CORDSET_CUSTOM_COLORS, ProductColorOption } from '../data/products';
import { Currency } from '../types';
import { formatPrice } from '../utils/format';
import { handleImageError } from '../utils/images';

interface ProductDetailModalProps {
  product: Product | null;
  currency: Currency;
  isWishlisted: boolean;
  onClose: () => void;
  onToggleWishlist: (product: Product) => void;
  onAddToCart: (
    product: Product,
    size: 'XS' | 'S' | 'M' | 'L' | 'XL' | 'Custom',
    customMeasurements?: {
      shirtLength?: string;
      chest?: string;
      trouserLength?: string;
      additionalNote?: string;
    },
    customColor?: {
      name: string;
      hex: string;
      neckline?: string;
      shirtLength?: string;
      trouserStyle?: string;
      isCustomToned?: boolean;
    }
  ) => void;
  onOpenSizeGuide: () => void;
  onOpenCustomColorStudio?: (product: Product) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  currency,
  isWishlisted,
  onClose,
  onToggleWishlist,
  onAddToCart,
  onOpenSizeGuide,
  onOpenCustomColorStudio,
}) => {
  if (!product) return null;

  const [activeImage, setActiveImage] = useState<string>(product.image);
  const [selectedSize, setSelectedSize] = useState<'XS' | 'S' | 'M' | 'L' | 'XL' | 'Custom'>('M');
  const [selectedColor, setSelectedColor] = useState<ProductColorOption>(
    product.customColorOptions ? product.customColorOptions[0] : { name: product.color, hex: product.colorHex }
  );
  const [customLength, setCustomLength] = useState<string>('');
  const [customChest, setCustomChest] = useState<string>('');
  const [customTrouser, setCustomTrouser] = useState<string>('');
  const [customNote, setCustomNote] = useState<string>('');
  const [addedSuccess, setAddedSuccess] = useState<boolean>(false);

  const images = [product.image, ...(product.secondaryImage ? [product.secondaryImage] : [])];

  const handleAddToCart = () => {
    const customData =
      selectedSize === 'Custom'
        ? {
            shirtLength: customLength || 'Standard 40"',
            chest: customChest || 'Standard 40"',
            trouserLength: customTrouser || 'Standard 39"',
            additionalNote: customNote,
          }
        : undefined;

    const colorData = product.isColorCustomizable
      ? {
          name: selectedColor.name,
          hex: selectedColor.hex,
          neckline: 'Double-Row Pearls',
          shirtLength: 'Standard 38"',
          trouserStyle: 'Flared Palazzo',
          isCustomToned: true,
        }
      : undefined;

    onAddToCart(product, selectedSize, customData, colorData);
    setAddedSuccess(true);
    setTimeout(() => {
      setAddedSuccess(false);
      onClose();
    }, 1200);
  };

  const [copiedForIg, setCopiedForIg] = useState(false);

  const handleInstagramOrder = () => {
    let msg = `Assalam o Alaikum Haya-e-Hayat! I would like to order:\n\n• Product: ${product.name}\n• Price: Rs. ${product.pricePKR}\n• Size: ${selectedSize}`;
    if (product.isColorCustomizable) {
      msg += `\n• Customized Color: ${selectedColor.name} (${selectedColor.hex})`;
    }
    if (selectedSize === 'Custom') {
      msg += `\n• Custom Sizing: Shirt: ${customLength || 'Standard 40"'}, Chest: ${customChest || 'Standard 40"'}, Trouser: ${customTrouser || 'Standard 39"'}\n• Note: ${customNote || 'None'}`;
    }
    msg += `\n\nPlease let me know order confirmation & Cash on Delivery delivery time.`;

    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(msg).catch(() => {});
    }
    setCopiedForIg(true);
    setTimeout(() => setCopiedForIg(false), 2500);

    window.open(INSTAGRAM_ORDER_URL, '_blank');
  };

  const handleWhatsAppOrder = () => {
    let msg = `Assalam o Alaikum Haya-e-Hayat! I want to order the following design:\n\n*Product:* ${product.name}\n*Price:* Rs. ${product.pricePKR}\n*Size:* ${selectedSize}`;
    if (product.isColorCustomizable) {
      msg += `\n*Customized Color:* ${selectedColor.name} (${selectedColor.hex})`;
    }
    if (selectedSize === 'Custom') {
      msg += `\n*Custom Measurements:* Shirt Length: ${customLength || 'Standard'}, Chest: ${customChest || 'Standard'}, Trouser: ${customTrouser || 'Standard'}\n*Notes:* ${customNote || 'None'}`;
    }
    msg += `\n\nPlease let me know order confirmation & Cash on Delivery delivery time.`;

    const encoded = encodeURIComponent(msg);
    window.open(`https://wa.me/923214292328?text=${encoded}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs overflow-y-auto">
      <div 
        className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl overflow-hidden my-8 border border-stone-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-full transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 max-h-[85vh] overflow-y-auto">
          {/* Left: Gallery Column */}
          <div className="md:col-span-6 bg-[#F8F6F2] p-6 flex flex-col justify-between">
            <div className="relative aspect-4/5 w-full rounded-xl overflow-hidden bg-stone-200 shadow-xs border border-stone-200">
              <img
                src={activeImage}
                alt={product.name}
                referrerPolicy="no-referrer"
                decoding="async"
                className="w-full h-full object-cover object-center"
                onError={handleImageError}
              />

              {/* Dynamic Color Tint when customizable */}
              {product.isColorCustomizable && activeImage === product.image && (
                <>
                  <div 
                    className="absolute inset-0 mix-blend-color opacity-70 pointer-events-none transition-colors duration-300"
                    style={{ backgroundColor: selectedColor.hex }}
                  />
                  <div 
                    className="absolute inset-0 mix-blend-multiply opacity-20 pointer-events-none transition-colors duration-300"
                    style={{ backgroundColor: selectedColor.hex }}
                  />
                  <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 bg-stone-900/90 text-stone-100 rounded-lg text-xs backdrop-blur-xs">
                    <span 
                      className="w-3 h-3 rounded-full border border-white/60"
                      style={{ backgroundColor: selectedColor.hex }}
                    />
                    <span className="font-medium">{selectedColor.name}</span>
                  </div>
                </>
              )}
            </div>

            {/* Thumbnail selector */}
            {images.length > 1 && (
              <div className="flex gap-3 mt-4">
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImage(img)}
                    className={`w-16 h-20 rounded-lg overflow-hidden border-2 transition-all cursor-pointer ${
                      activeImage === img ? 'border-stone-900 shadow-sm' : 'border-stone-300 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt={`${product.name} - view`} loading="lazy" decoding="async" className="w-full h-full object-cover" onError={handleImageError} />
                  </button>
                ))}
              </div>
            )}

            {/* Quality badge */}
            <div className="mt-4 p-3 bg-stone-100/80 rounded-lg border border-stone-200 flex items-center gap-3 text-xs text-stone-600">
              <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0" />
              <div>
                <span className="font-semibold text-stone-800">Authentic Karachi Atelier Quality:</span> Every piece is inspected for clean stitching, accurate threadwork, and pre-shrunk fabric.
              </div>
            </div>
          </div>

          {/* Right: Details & Purchase Module */}
          <div className="md:col-span-6 p-6 sm:p-8 flex flex-col justify-between">
            <div className="space-y-4">
              {/* Category & Rating */}
              <div className="flex items-center justify-between text-xs text-stone-500">
                <span className="font-semibold uppercase tracking-widest text-stone-600">
                  {product.categoryLabel}
                </span>
                <div className="flex items-center gap-1.5 text-stone-700">
                  <span className="text-amber-500">★</span>
                  <span className="font-semibold tabular-nums">{product.rating}</span>
                  <span className="text-stone-400">({product.reviewCount} reviews)</span>
                </div>
              </div>

              {/* Title & Urdu Name */}
              <div>
                <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-stone-900 leading-tight">
                  {product.name}
                </h2>
                {product.urduName && (
                  <div className="text-sm font-serif text-stone-500 mt-1">
                    {product.urduName}
                  </div>
                )}
              </div>

              {/* Price & Savings */}
              <div className="flex items-baseline gap-3 py-2 border-y border-stone-100">
                <span className="font-serif text-2xl font-bold text-stone-900 tabular-nums">
                  {formatPrice(product.pricePKR, currency)}
                </span>
                {product.originalPricePKR > product.pricePKR && (
                  <>
                    <span className="text-sm text-stone-400 line-through tabular-nums">
                      {formatPrice(product.originalPricePKR, currency)}
                    </span>
                    <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                      Save {formatPrice(product.originalPricePKR - product.pricePKR, currency)}
                    </span>
                  </>
                )}
              </div>

              {/* Description */}
              <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                {product.description}
              </p>

              {/* Fabric Specs */}
              <div className="grid grid-cols-2 gap-2 text-xs bg-stone-50 p-3 rounded-xl border border-stone-200">
                <div>
                  <span className="text-stone-500">Fabric:</span>
                  <p className="font-medium text-stone-800">{product.fabric}</p>
                </div>
                <div>
                  <span className="text-stone-500">Package:</span>
                  <p className="font-medium text-stone-800">{product.packageContains}</p>
                </div>
              </div>

              {/* Customizable Favorite Color Swatches */}
              {product.isColorCustomizable && (
                <div className="p-3.5 bg-gradient-to-r from-amber-50/70 via-rose-50/40 to-stone-50 rounded-xl border border-amber-200/80 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <Palette className="w-4 h-4 text-amber-700" />
                      <span className="text-xs font-bold text-stone-900 tracking-tight">
                        Customize in Your Favorite Color✨🫶🏻
                      </span>
                    </div>
                    {onOpenCustomColorStudio && (
                      <button
                        onClick={() => onOpenCustomColorStudio(product)}
                        className="text-[11px] font-semibold text-rose-800 hover:text-rose-950 flex items-center gap-1 underline cursor-pointer"
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>Bespoke Studio</span>
                      </button>
                    )}
                  </div>

                  <p className="text-[11px] text-stone-600 leading-snug">
                    Solid 2-piece, affordable workwear, university girl outfit. Choose from 12+ shades or custom dye your shade!
                  </p>

                  {/* Swatches strip */}
                  <div className="flex items-center gap-2 flex-wrap">
                    {CORDSET_CUSTOM_COLORS.slice(0, 8).map((col) => {
                      const isSelected = selectedColor.name === col.name;
                      return (
                        <button
                          key={col.name}
                          onClick={() => setSelectedColor(col)}
                          title={`${col.name} (${col.urduName || ''})`}
                          className={`w-7 h-7 rounded-full border-2 transition-all flex items-center justify-center cursor-pointer shadow-xs ${
                            isSelected
                              ? 'border-stone-900 scale-115 ring-2 ring-stone-900/30'
                              : 'border-white hover:scale-105 opacity-90'
                          }`}
                          style={{ backgroundColor: col.hex }}
                        >
                          {isSelected && (
                            <Check className={`w-3.5 h-3.5 ${col.textColor === 'dark' ? 'text-stone-900' : 'text-white'}`} />
                          )}
                        </button>
                      );
                    })}

                    {onOpenCustomColorStudio && (
                      <button
                        onClick={() => onOpenCustomColorStudio(product)}
                        className="px-2 py-1 bg-white hover:bg-stone-100 border border-stone-300 rounded-full text-[10px] font-medium text-stone-700 shadow-xs flex items-center gap-1 cursor-pointer"
                      >
                        <span>+ More</span>
                      </button>
                    )}
                  </div>

                  <div className="flex items-center justify-between text-[11px] pt-0.5">
                    <span className="text-stone-600">Selected Shade:</span>
                    <span className="font-semibold text-stone-900 flex items-center gap-1.5">
                      <span 
                        className="w-2.5 h-2.5 rounded-full border border-stone-300 inline-block"
                        style={{ backgroundColor: selectedColor.hex }}
                      />
                      {selectedColor.name}
                    </span>
                  </div>
                </div>
              )}

              {/* Size Selector */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-stone-800">
                    Select Size: <span className="text-stone-500 font-normal">({selectedSize})</span>
                  </span>
                  <button
                    onClick={onOpenSizeGuide}
                    className="text-xs text-stone-600 hover:text-stone-900 flex items-center gap-1 underline underline-offset-2 cursor-pointer"
                  >
                    <Ruler className="w-3.5 h-3.5 text-stone-700" />
                    <span>View Size Chart</span>
                  </button>
                </div>

                <div className="grid grid-cols-6 gap-2">
                  {product.availableSizes.map((sz) => (
                    <button
                      key={sz}
                      onClick={() => setSelectedSize(sz)}
                      className={`py-2 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                        selectedSize === sz
                          ? 'border-stone-900 bg-stone-900 text-stone-50 shadow-xs'
                          : 'border-stone-200 bg-white text-stone-700 hover:border-stone-400'
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Measurement Section */}
              {selectedSize === 'Custom' && (
                <div className="p-3.5 bg-amber-50/60 rounded-xl border border-amber-200 text-xs space-y-2">
                  <div className="font-semibold text-amber-900">
                    Custom Tailoring Details (Inches)
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="text-[11px] text-amber-800">Shirt Length</label>
                      <input
                        type="text"
                        placeholder='e.g. 42"'
                        value={customLength}
                        onChange={(e) => setCustomLength(e.target.value)}
                        className="w-full mt-0.5 px-2 py-1 bg-white border border-amber-300 rounded text-xs"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-amber-800">Chest Size</label>
                      <input
                        type="text"
                        placeholder='e.g. 39"'
                        value={customChest}
                        onChange={(e) => setCustomChest(e.target.value)}
                        className="w-full mt-0.5 px-2 py-1 bg-white border border-amber-300 rounded text-xs"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-amber-800">Trouser Length</label>
                      <input
                        type="text"
                        placeholder='e.g. 38"'
                        value={customTrouser}
                        onChange={(e) => setCustomTrouser(e.target.value)}
                        className="w-full mt-0.5 px-2 py-1 bg-white border border-amber-300 rounded text-xs"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-[11px] text-amber-800">Special Instructions / Neckline preference</label>
                    <input
                      type="text"
                      placeholder="e.g., Modest closed neckline, 1-inch extra sleeve cuff"
                      value={customNote}
                      onChange={(e) => setCustomNote(e.target.value)}
                      className="w-full mt-0.5 px-2 py-1 bg-white border border-amber-300 rounded text-xs"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Actions */}
            <div className="space-y-3 pt-6 mt-6 border-t border-stone-200">
              <div className="flex gap-3">
                <button
                  onClick={handleAddToCart}
                  className={`flex-1 py-3 px-4 rounded-xl font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    addedSuccess
                      ? 'bg-emerald-700 text-white'
                      : 'bg-stone-900 hover:bg-stone-800 text-stone-50 shadow-md'
                  }`}
                >
                  {addedSuccess ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Added to Your Bag!</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4 text-stone-300" />
                      <span>Add to Bag · {formatPrice(product.pricePKR, currency)}</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => onToggleWishlist(product)}
                  className={`p-3 rounded-xl border transition-colors cursor-pointer ${
                    isWishlisted
                      ? 'bg-rose-50 border-rose-200 text-rose-600'
                      : 'border-stone-200 hover:border-stone-400 text-stone-600'
                  }`}
                  aria-label="Wishlist"
                >
                  <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
                </button>
              </div>

              {/* Direct Instagram & WhatsApp Ordering */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  onClick={handleInstagramOrder}
                  className="py-2.5 px-3 bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#FCB045] hover:opacity-95 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 shadow-xs transition-opacity cursor-pointer"
                  title="DM on Instagram @hayaehayat to order"
                >
                  <Instagram className="w-4 h-4 shrink-0" />
                  <span className="truncate">
                    {copiedForIg ? 'Details Copied! Opening DM...' : 'DM on Instagram to Order'}
                  </span>
                </button>

                <button
                  onClick={handleWhatsAppOrder}
                  className="py-2.5 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span className="truncate">WhatsApp Order</span>
                </button>
              </div>

              <div className="flex items-center justify-between text-[11px] text-stone-500 pt-1">
                <div className="flex items-center gap-1.5 font-medium text-emerald-800">
                  <Truck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Free Delivery All Over Pakistan · COD</span>
                </div>
                <span>7-Day Easy Exchange Policy</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
