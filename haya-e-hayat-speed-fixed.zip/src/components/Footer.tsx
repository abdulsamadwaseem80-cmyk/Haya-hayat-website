import React from 'react';
import { Instagram, Phone, Mail, Heart, ArrowUp } from 'lucide-react';

interface FooterProps {
  onSelectCategory: (cat: string) => void;
  onOpenSizeGuide: () => void;
  onOpenAboutUs?: () => void;
  onOpenSourceCode?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectCategory, onOpenSizeGuide, onOpenAboutUs, onOpenSourceCode }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#211F1D] text-stone-300 text-xs border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-14 sm:py-18">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <span className="font-serif text-2xl font-bold tracking-[0.16em] uppercase text-white block">
              Haya-e-Hayat
            </span>
            <p className="text-stone-400 leading-relaxed max-w-sm">
              Contemporary Pakistani modest fashion & artisanal cutwork pret. From everyday university sets to intimate festive wear, we celebrate effortless grace and modest silhouettes.
            </p>
            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://www.instagram.com/hayaehayat?stkn=MXIwZHJsNngzdWpwYQ=="
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-full bg-stone-800 hover:bg-[#E1306C] text-stone-300 hover:text-white flex items-center justify-center transition-colors"
                title="Follow on Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://wa.me/923214292328"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-full bg-stone-800 hover:bg-emerald-600 text-stone-300 hover:text-white flex items-center justify-center transition-colors"
                title="WhatsApp Concierge"
              >
                <Phone className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="font-semibold uppercase tracking-wider text-stone-100 text-[11px]">
              Collections
            </h4>
            <ul className="space-y-2 text-stone-400">
              <li>
                <button
                  onClick={() => onSelectCategory('coord-sets')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  2-Piece Co-ord Sets
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('embroidered-pret')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Cutwork Embroidered Pret
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('university-edit')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  University Daily Staples
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('festive-wear')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Festive Occasion Ensembles
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('all')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  View All Designs
                </button>
              </li>
            </ul>
          </div>

          {/* Customer Care */}
          <div className="space-y-3">
            <h4 className="font-semibold uppercase tracking-wider text-stone-100 text-[11px]">
              Customer Care & Story
            </h4>
            <ul className="space-y-2 text-stone-400">
              <li>
                <button
                  onClick={() => {
                    if (onOpenAboutUs) {
                      onOpenAboutUs();
                    } else {
                      const el = document.getElementById('about');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                  className="hover:text-white transition-colors cursor-pointer text-left font-medium text-amber-200/90"
                >
                  About Us (Our Philosophy)
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenSizeGuide}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Size Chart & Measurements
                </button>
              </li>
              <li>
                <a href="#atelier" className="hover:text-white transition-colors">
                  Custom Sizing Policy
                </a>
              </li>
              <li>
                <a href="#atelier" className="hover:text-white transition-colors">
                  7-Day Exchange Process
                </a>
              </li>
              <li>
                <a href="#atelier" className="hover:text-white transition-colors">
                  Cash on Delivery Info
                </a>
              </li>
              <li>
                <a
                  href="https://www.instagram.com/hayaehayat?stkn=MXIwZHJsNngzdWpwYQ=="
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-pink-400 hover:text-pink-300 font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Instagram className="w-3.5 h-3.5" />
                  <span>DM on Instagram to Order</span>
                </a>
              </li>
              <li>
                <a href="https://wa.me/923214292328" className="hover:text-white transition-colors">
                  Track Existing Order
                </a>
              </li>
            </ul>
          </div>

          {/* Karachi Atelier */}
          <div className="space-y-3">
            <h4 className="font-semibold uppercase tracking-wider text-stone-100 text-[11px]">
              Karachi Atelier
            </h4>
            <div className="space-y-2 text-stone-400">
              <p>CMT Stitching Unit & Logistics</p>
              <p>Karachi, Sindh, Pakistan</p>
              <p className="text-stone-300 font-medium pt-1">
                WhatsApp: <a href="https://wa.me/923214292328" className="text-emerald-400 hover:underline">+92 321 4292328</a>
              </p>
              <p className="text-stone-300 font-medium">
                Instagram DM: <a href="https://www.instagram.com/hayaehayat?stkn=MXIwZHJsNngzdWpwYQ==" target="_blank" rel="noopener noreferrer" className="text-pink-400 hover:underline">@hayaehayat</a>
              </p>
              <p className="text-[11px] text-stone-500">Mon - Sat: 10:00 AM - 9:00 PM</p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-stone-500">
          <div>
            © {new Date().getFullYear()} Haya-e-Hayat (@hayaehayat). All Rights Reserved. Handcrafted in Karachi, Pakistan.
          </div>

          <div className="flex items-center gap-3">
            <span className="text-emerald-400 font-medium">Free Delivery All Over Pakistan</span>
            <span className="text-stone-700">·</span>
            <span>Cash on Delivery (COD)</span>
            <span className="text-stone-700">·</span>
            <span>Bank Transfer</span>
            <button
              onClick={scrollToTop}
              className="p-2 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-full transition-colors"
              title="Scroll to top"
            >
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
