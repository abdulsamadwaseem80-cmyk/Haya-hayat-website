import React from 'react';
import { Instagram, ExternalLink, Heart, Sparkles } from 'lucide-react';
import { INSTAGRAM_HIGHLIGHTS } from '../data/products';
import { handleImageError } from '../utils/images';

interface InstagramFeedProps {
  onShopCollection: () => void;
}

export const InstagramFeed: React.FC<InstagramFeedProps> = ({ onShopCollection }) => {
  return (
    <section className="py-14 sm:py-20 bg-[#F4F1EA] border-t border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-stone-500 mb-1">
              <Instagram className="w-3.5 h-3.5 text-pink-700" />
              <span>Live Social Diary</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl font-medium text-stone-900">
              Styled by Our Community
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <a
              href="https://www.instagram.com/hayaehayat?stkn=MXIwZHJsNngzdWpwYQ=="
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-stone-900 hover:bg-stone-800 text-stone-50 text-xs font-semibold rounded-lg transition-colors shadow-xs"
            >
              <Instagram className="w-4 h-4 text-pink-300" />
              <span>Follow @hayaehayat</span>
              <ExternalLink className="w-3.5 h-3.5 text-stone-400" />
            </a>
          </div>
        </div>

        {/* 4-Item Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {INSTAGRAM_HIGHLIGHTS.map((post) => (
            <div
              key={post.id}
              className="group rounded-2xl overflow-hidden bg-white border border-stone-200/90 shadow-xs hover:shadow-md transition-all duration-300 flex flex-col"
            >
              <div className="relative aspect-square overflow-hidden bg-stone-100">
                <img
                  src={post.image}
                  alt={post.caption}
                  referrerPolicy="no-referrer"
                  loading="lazy"
                  decoding="async"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  onError={handleImageError}
                />
                
                {/* Hover overlay with link */}
                <a
                  href="https://www.instagram.com/hayaehayat?stkn=MXIwZHJsNngzdWpwYQ=="
                  target="_blank"
                  rel="noopener noreferrer"
                  className="absolute inset-0 bg-stone-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 text-white text-xs font-semibold backdrop-blur-2xs"
                >
                  <Instagram className="w-4 h-4" />
                  <span>View on Instagram</span>
                </a>

                {/* Corner like badge */}
                <div className="absolute bottom-2.5 right-2.5 px-2 py-1 bg-stone-900/70 backdrop-blur-xs text-white text-[10px] font-semibold rounded-md flex items-center gap-1">
                  <Heart className="w-3 h-3 text-rose-400 fill-current" />
                  <span className="tabular-nums">{post.likes}</span>
                </div>
              </div>

              <div className="p-4 flex-1 flex flex-col justify-between">
                <p className="text-xs text-stone-700 leading-relaxed line-clamp-3">
                  {post.caption}
                </p>

                <div className="mt-3 pt-3 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-500">
                  <span className="font-semibold text-stone-900">{post.handle}</span>
                  <span>{post.date}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Customer Reviews Spotlight */}
        <div className="mt-12 pt-10 border-t border-stone-300/80">
          <div className="text-center max-w-xl mx-auto mb-8">
            <span className="text-xs font-semibold tracking-widest uppercase text-stone-500">
              Verified Feedback
            </span>
            <h3 className="font-serif text-2xl font-bold text-stone-900 mt-1">
              Loved by Students & Working Women
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-5 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-3">
              <div className="flex text-amber-500 text-sm">★★★★★</div>
              <p className="text-xs text-stone-700 leading-relaxed italic">
                "Ordered the Sage linen co-ord for university presentations. The cutwork on the sleeves is impeccable, and the fabric breathes so well in Karachi's humidity."
              </p>
              <div className="pt-2 border-t border-stone-100 text-xs">
                <div className="font-semibold text-stone-900">Ayesha Tariq</div>
                <div className="text-[11px] text-stone-500">Karachi (IBA Student) · Verified Buyer</div>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-3">
              <div className="flex text-amber-500 text-sm">★★★★★</div>
              <p className="text-xs text-stone-700 leading-relaxed italic">
                "Requested customized shirt and trouser lengths over WhatsApp. They accommodated my modest specifications with zero hassle. Arrived via COD in 3 days!"
              </p>
              <div className="pt-2 border-t border-stone-100 text-xs">
                <div className="font-semibold text-stone-900">Zainab Noor</div>
                <div className="text-[11px] text-stone-500">Lahore (DHA Phase 5) · Verified Buyer</div>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-white border border-stone-200 shadow-xs space-y-3">
              <div className="flex text-amber-500 text-sm">★★★★★</div>
              <p className="text-xs text-stone-700 leading-relaxed italic">
                "Finally a Pakistani brand that understands modern modest aesthetics without overcharging. Pure fabric, clean stitching, and durable seams."
              </p>
              <div className="pt-2 border-t border-stone-100 text-xs">
                <div className="font-semibold text-stone-900">Dr. Mahnoor Khan</div>
                <div className="text-[11px] text-stone-500">Islamabad · Verified Buyer</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
