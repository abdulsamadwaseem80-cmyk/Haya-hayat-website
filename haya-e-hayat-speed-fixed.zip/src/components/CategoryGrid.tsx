import React from 'react';
import { ArrowUpRight } from 'lucide-react';
import { resolveImage, handleImageError } from '../utils/images';

interface CategoryGridProps {
  onSelectCategory: (categoryId: string) => void;
}

const CATEGORY_TILES = [
  {
    id: 'coord-sets',
    title: 'Solid & Cutwork Co-ords',
    subtitle: 'Affordable workwear, solid 2-piece sets & university girl favorites',
    tag: 'Favorite Colors ✨',
    image: resolveImage('/src/assets/images/plum_coord_set_1790262536094.jpg'),
  },
  {
    id: 'festive-wear',
    title: 'Festive Gota-Patti Sets',
    subtitle: 'Kalidar flared kurtis with geometric ivory gota trousers in 4 colors',
    tag: 'New Festive Drop',
    image: resolveImage('/src/assets/images/gota_navy_festive_1790262572910.jpg'),
  },
  {
    id: 'university-edit',
    title: 'University Daily Staples',
    subtitle: 'Comfortable, breathable modest tunics & co-ords for campus life',
    tag: 'Campus Favorite',
    image: resolveImage('/src/assets/images/category_university_edits_1790260569649.jpg'),
  },
  {
    id: 'embroidered-pret',
    title: 'Cutwork Embroidered Pret',
    subtitle: 'Signature intricate cutwork daaman, cuffs, and neckline details',
    tag: 'Artisanal Craft',
    image: resolveImage('/src/assets/images/category_embroidered_pret_1790260557863.jpg'),
  },
];

export const CategoryGrid: React.FC<CategoryGridProps> = ({ onSelectCategory }) => {
  return (
    <section className="py-12 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
        <div>
          <div className="text-xs font-semibold tracking-widest uppercase text-stone-500 mb-1">
            Carefully Crafted Silhouettes
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl font-medium text-stone-900">
            Curated Collections
          </h2>
        </div>
        <p className="text-sm text-stone-600 max-w-md">
          Explore our hallmark categories tailored for modern Pakistani women seeking effortless comfort, modesty, and distinctive embroidery.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {CATEGORY_TILES.map((tile) => (
          <div
            key={tile.id}
            onClick={() => {
              onSelectCategory(tile.id);
              const el = document.getElementById('catalog');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className="group cursor-pointer rounded-2xl overflow-hidden bg-white border border-stone-200/90 hover:border-stone-400/90 shadow-xs hover:shadow-md transition-all duration-300 flex flex-col"
          >
            {/* Visual Image container */}
            <div className="relative aspect-4/3 overflow-hidden bg-stone-100">
              <img
                src={tile.image}
                alt={tile.title}
                referrerPolicy="no-referrer"
                loading="lazy"
                decoding="async"
                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                onError={handleImageError}
              />
              <span className="absolute top-3 left-3 text-[11px] font-semibold px-2 py-0.5 bg-stone-900/80 backdrop-blur-xs text-stone-100 rounded">
                {tile.tag}
              </span>
            </div>

            {/* Content description */}
            <div className="p-5 flex-1 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <h3 className="font-serif text-lg font-semibold text-stone-900 group-hover:text-stone-700 transition-colors">
                    {tile.title}
                  </h3>
                  <ArrowUpRight className="w-4 h-4 text-stone-400 group-hover:text-stone-900 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
                </div>
                <p className="text-xs text-stone-600 mt-2 line-clamp-2 leading-relaxed">
                  {tile.subtitle}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-stone-100 flex items-center text-xs font-semibold text-stone-800 group-hover:text-stone-950">
                <span>View Designs</span>
                <span className="ml-1 text-stone-400">→</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
