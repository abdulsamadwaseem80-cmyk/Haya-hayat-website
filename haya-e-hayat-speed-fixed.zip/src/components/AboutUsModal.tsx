import React from 'react';
import { X, Sparkles, ShieldCheck, Heart, Instagram, Phone, MapPin, Truck } from 'lucide-react';
import { INSTAGRAM_ORDER_URL, INSTAGRAM_HANDLE } from '../data/products';

interface AboutUsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExploreCollection: () => void;
}

export const AboutUsModal: React.FC<AboutUsModalProps> = ({
  isOpen,
  onClose,
  onExploreCollection,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs overflow-y-auto">
      <div
        className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden my-8 border border-stone-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header background & Close button */}
        <div className="relative bg-[#F7F4EE] px-6 py-8 sm:px-8 border-b border-stone-200">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-2 bg-white/80 hover:bg-white text-stone-700 rounded-full transition-colors cursor-pointer shadow-xs"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-stone-500 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-700" />
            <span>Brand Story & Heritage</span>
          </div>

          <h2 className="font-serif text-3xl sm:text-4xl font-semibold tracking-tight text-stone-900">
            About Haya-e-Hayat
          </h2>
          <p className="text-xs font-sans tracking-[0.2em] uppercase text-stone-500 mt-1">
            Haute Modestie · Handcrafted in Karachi, Pakistan
          </p>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 space-y-6 max-h-[70vh] overflow-y-auto">
          {/* User's exact official statement */}
          <div className="p-5 rounded-2xl bg-[#FAF9F6] border border-stone-200/90 shadow-2xs space-y-4">
            <p className="font-serif text-base sm:text-lg text-stone-900 leading-relaxed italic border-l-3 border-stone-800 pl-4 py-1">
              "Welcome to Haya e Hayat, where timeless elegance meets modern sophistication. Founded on the belief that modesty is an expression of grace and self-assurance, our clothing is crafted for the contemporary individual who values both tradition and style."
            </p>

            <p className="text-xs sm:text-sm text-stone-700 leading-relaxed">
              At Haya e Hayat, every piece tells a story of refined craftsmanship. We source premium fabrics and blend classic cuts with modern trends to create attire that feels luxurious, comfortable, and empowering. Whether for daily wear or memorable occasions, our collections are designed to reflect modesty as a lifestyle—celebrating dignity, beauty, and individuality in every thread.
            </p>
          </div>

          {/* Pillars */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <div className="p-3.5 rounded-xl border border-stone-200 bg-white space-y-1">
              <div className="flex items-center gap-1.5 text-stone-900 font-semibold text-xs">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                <span>Refined Fabrics</span>
              </div>
              <p className="text-[11px] text-stone-500 leading-relaxed">
                Pre-shrunk, breathable linen, lawn, and cambric cotton tailored for comfort in all seasons.
              </p>
            </div>

            <div className="p-3.5 rounded-xl border border-stone-200 bg-white space-y-1">
              <div className="flex items-center gap-1.5 text-stone-900 font-semibold text-xs">
                <Heart className="w-4 h-4 text-rose-600" />
                <span>Modesty as Lifestyle</span>
              </div>
              <p className="text-[11px] text-stone-500 leading-relaxed">
                Generous cuts, modest necklines, and flowing flares celebrating dignity & self-assurance.
              </p>
            </div>

            <div className="p-3.5 rounded-xl border border-stone-200 bg-white space-y-1">
              <div className="flex items-center gap-1.5 text-stone-900 font-semibold text-xs">
                <Truck className="w-4 h-4 text-emerald-700" />
                <span>Karachi Atelier</span>
              </div>
              <p className="text-[11px] text-stone-500 leading-relaxed">
                Direct CMT manufacturing facility with swift dispatch across Pakistan & worldwide.
              </p>
            </div>
          </div>

          {/* Contact Details from Google Business Profile */}
          <div className="pt-2 border-t border-stone-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-stone-600">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-stone-400 shrink-0" />
              <span>Karachi CMT Stitching Unit, Sindh, Pakistan</span>
            </div>
            <div className="flex items-center gap-3">
              <a
                href={INSTAGRAM_ORDER_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 font-semibold text-pink-700 hover:underline"
              >
                <Instagram className="w-3.5 h-3.5" />
                <span>{INSTAGRAM_HANDLE}</span>
              </a>
              <span className="text-stone-300">·</span>
              <a
                href="https://wa.me/923214292328"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 font-semibold text-emerald-700 hover:underline"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>+92 321 4292328</span>
              </a>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="pt-2 flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => {
                onClose();
                onExploreCollection();
              }}
              className="flex-1 py-3 px-4 bg-stone-900 hover:bg-stone-800 text-stone-50 rounded-xl text-xs font-semibold text-center transition-colors cursor-pointer shadow-xs"
            >
              Explore Collection
            </button>

            <a
              href={INSTAGRAM_ORDER_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="py-3 px-4 bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#FCB045] hover:opacity-95 text-white rounded-xl text-xs font-semibold text-center transition-opacity flex items-center justify-center gap-2 shadow-xs"
            >
              <Instagram className="w-4 h-4" />
              <span>DM on Instagram (@hayaehayat)</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
