import React from 'react';
import { Search, Heart, ShoppingBag, Instagram, Sparkles, Palette, Code2 } from 'lucide-react';
import { INSTAGRAM_ORDER_URL } from '../data/products';

interface HeaderProps {
  cartCount: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenSearch: () => void;
  onOpenAboutUs?: () => void;
  onOpenCustomColorStudio?: () => void;
  onOpenSourceCode?: () => void;
  onSelectCategory: (cat: string) => void;
  activeCategory: string;
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  wishlistCount,
  onOpenCart,
  onOpenWishlist,
  onOpenSearch,
  onOpenAboutUs,
  onOpenCustomColorStudio,
  onOpenSourceCode,
  onSelectCategory,
  activeCategory,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#FAF9F6]/95 backdrop-blur-md border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-18 sm:h-20 flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            onSelectCategory('all');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="group flex flex-col items-start leading-none"
        >
          <span className="font-serif text-2xl sm:text-3xl font-semibold tracking-[0.16em] uppercase text-stone-900 group-hover:text-stone-700 transition-colors">
            Haya-e-Hayat
          </span>
          <span className="text-[10px] tracking-[0.24em] uppercase text-stone-500 font-sans mt-0.5">
            Haute Modestie · Karachi
          </span>
        </a>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium tracking-wide text-stone-700">
          <button
            onClick={() => onSelectCategory('all')}
            className={`transition-colors hover:text-stone-900 cursor-pointer ${
              activeCategory === 'all' ? 'text-stone-900 font-semibold underline underline-offset-8 decoration-stone-800' : 'text-stone-600'
            }`}
          >
            All Products
          </button>
          <button
            onClick={() => onSelectCategory('coord-sets')}
            className={`transition-colors hover:text-stone-900 cursor-pointer ${
              activeCategory === 'coord-sets' ? 'text-stone-900 font-semibold underline underline-offset-8 decoration-stone-800' : 'text-stone-600'
            }`}
          >
            2-Piece Co-ords
          </button>
          <button
            onClick={() => onSelectCategory('embroidered-pret')}
            className={`transition-colors hover:text-stone-900 cursor-pointer ${
              activeCategory === 'embroidered-pret' ? 'text-stone-900 font-semibold underline underline-offset-8 decoration-stone-800' : 'text-stone-600'
            }`}
          >
            Cutwork Pret
          </button>
          <button
            onClick={() => onSelectCategory('university-edit')}
            className={`transition-colors hover:text-stone-900 cursor-pointer ${
              activeCategory === 'university-edit' ? 'text-stone-900 font-semibold underline underline-offset-8 decoration-stone-800' : 'text-stone-600'
            }`}
          >
            University Edit
          </button>
          <button
            onClick={() => onSelectCategory('festive-wear')}
            className={`transition-colors hover:text-stone-900 cursor-pointer ${
              activeCategory === 'festive-wear' ? 'text-stone-900 font-semibold underline underline-offset-8 decoration-stone-800' : 'text-stone-600'
            }`}
          >
            Festive Ensembles
          </button>
          {onOpenCustomColorStudio && (
            <button
              onClick={onOpenCustomColorStudio}
              className="px-2.5 py-1 rounded-full bg-amber-50 border border-amber-300/80 hover:bg-amber-100 text-stone-800 text-xs font-semibold transition-colors flex items-center gap-1 cursor-pointer"
              title="Customize solid 2-piece sets in your favorite color"
            >
              <Palette className="w-3.5 h-3.5 text-amber-700" />
              <span>Customize Color ✨</span>
            </button>
          )}
          <button
            onClick={() => {
              if (onOpenAboutUs) {
                onOpenAboutUs();
              } else {
                const el = document.getElementById('about');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }
            }}
            className="text-stone-600 hover:text-stone-900 transition-colors cursor-pointer"
          >
            About Us
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions (Search, Wishlist, Bag) */}
        <div className="flex items-center gap-2 sm:gap-3">
          <a
            href={INSTAGRAM_ORDER_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg border border-pink-200/90 bg-gradient-to-r from-pink-50 to-rose-50 text-pink-700 hover:text-pink-800 text-xs font-semibold transition-all shadow-2xs hover:shadow-xs"
            title="DM us on Instagram @hayaehayat to order"
          >
            <Instagram className="w-3.5 h-3.5 text-pink-600" />
            <span className="hidden xs:inline">DM to Order</span>
            <span className="xs:hidden">DM</span>
          </a>

          <button
            onClick={onOpenSearch}
            className="p-2 text-stone-600 hover:text-stone-900 rounded-full hover:bg-stone-100 transition-colors"
            title="Search products"
            aria-label="Search collection"
          >
            <Search className="w-5 h-5" />
          </button>

          <button
            onClick={onOpenWishlist}
            className="relative p-2 text-stone-600 hover:text-stone-900 rounded-full hover:bg-stone-100 transition-colors"
            title="View Wishlist"
            aria-label="Wishlist"
          >
            <Heart className="w-5 h-5" />
            {wishlistCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 bg-stone-800 text-stone-100 text-[10px] font-semibold rounded-full flex items-center justify-center">
                {wishlistCount}
              </span>
            )}
          </button>

          <button
            onClick={onOpenCart}
            className="flex items-center gap-2 px-3.5 py-2 bg-stone-900 text-stone-50 rounded-lg hover:bg-stone-800 transition-colors shadow-sm cursor-pointer whitespace-nowrap"
            aria-label="Shopping Bag"
          >
            <ShoppingBag className="w-4 h-4 text-stone-200" />
            <span className="text-xs font-semibold tracking-wider uppercase">Bag</span>
            <span className="w-5 h-5 bg-[#CBB593] text-stone-950 text-xs font-bold rounded-full flex items-center justify-center">
              {cartCount}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
