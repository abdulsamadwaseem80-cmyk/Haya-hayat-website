import React, { useState } from 'react';
import { X, Ruler, CheckCircle2, MessageCircle } from 'lucide-react';
import { SIZE_CHART } from '../data/products';

interface SizeGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SizeGuideModal: React.FC<SizeGuideModalProps> = ({ isOpen, onClose }) => {
  const [unit, setUnit] = useState<'in' | 'cm'>('in');
  const [customChest, setCustomChest] = useState('');
  const [customLength, setCustomLength] = useState('');
  const [customSleeve, setCustomSleeve] = useState('');
  const [customTrouser, setCustomTrouser] = useState('');
  const [customerName, setCustomerName] = useState('');

  if (!isOpen) return null;

  const handleSendCustomInquiry = (e: React.FormEvent) => {
    e.preventDefault();
    const msg = `Assalam o Alaikum Haya-e-Hayat! My name is ${customerName || 'Customer'}. I would like to consult regarding custom sizing for an outfit:\n\n- Desired Chest: ${customChest || 'Not specified'}\n- Desired Shirt Length: ${customLength || 'Not specified'}\n- Desired Sleeve Length: ${customSleeve || 'Not specified'}\n- Desired Trouser Length: ${customTrouser || 'Not specified'}\n\nPlease guide me on availability and stitching timeframe.`;
    window.open(`https://wa.me/923214292328?text=${encodeURIComponent(msg)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs overflow-y-auto">
      <div 
        className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl p-6 sm:p-8 my-8 border border-stone-200"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-full transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-full bg-[#EADFCB] flex items-center justify-center text-stone-800">
            <Ruler className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-serif text-2xl font-bold text-stone-900">
              Haya-e-Hayat Size & Custom Sizing Guide
            </h2>
            <p className="text-xs text-stone-500">
              Standard Pakistani pret sizing and personalized tailoring measurements
            </p>
          </div>
        </div>

        {/* Unit Toggle */}
        <div className="flex justify-end my-4">
          <div className="inline-flex rounded-lg border border-stone-200 p-0.5 bg-stone-100 text-xs">
            <button
              onClick={() => setUnit('in')}
              className={`px-3 py-1 rounded-md font-medium transition-colors ${
                unit === 'in' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600'
              }`}
            >
              Inches (in)
            </button>
            <button
              onClick={() => setUnit('cm')}
              className={`px-3 py-1 rounded-md font-medium transition-colors ${
                unit === 'cm' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600'
              }`}
            >
              Centimeters (cm)
            </button>
          </div>
        </div>

        {/* Size Table */}
        <div className="overflow-x-auto rounded-xl border border-stone-200">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#F8F6F1] border-b border-stone-200 text-stone-700 font-semibold">
              <tr>
                <th className="py-2.5 px-3">Size</th>
                <th className="py-2.5 px-3">Chest (Bust)</th>
                <th className="py-2.5 px-3">Shirt Length</th>
                <th className="py-2.5 px-3">Shoulder</th>
                <th className="py-2.5 px-3">Sleeve</th>
                <th className="py-2.5 px-3">Trouser Length</th>
                <th className="py-2.5 px-3">Trouser Waist</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 text-stone-600">
              {SIZE_CHART.map((s) => {
                const parseInToCm = (val: string) => {
                  const num = parseFloat(val.replace(/"/g, ''));
                  return isNaN(num) ? val : `${Math.round(num * 2.54)} cm`;
                };

                return (
                  <tr key={s.size} className="hover:bg-stone-50/70">
                    <td className="py-2.5 px-3 font-bold text-stone-900 bg-stone-50/40">
                      {s.size}
                    </td>
                    <td className="py-2.5 px-3 tabular-nums">
                      {unit === 'in' ? s.chest : parseInToCm(s.chest)}
                    </td>
                    <td className="py-2.5 px-3 tabular-nums">
                      {unit === 'in' ? s.shirtLength : parseInToCm(s.shirtLength)}
                    </td>
                    <td className="py-2.5 px-3 tabular-nums">
                      {unit === 'in' ? s.shoulder : parseInToCm(s.shoulder)}
                    </td>
                    <td className="py-2.5 px-3 tabular-nums">
                      {unit === 'in' ? s.sleeveLength : parseInToCm(s.sleeveLength)}
                    </td>
                    <td className="py-2.5 px-3 tabular-nums">
                      {unit === 'in' ? s.trouserLength : parseInToCm(s.trouserLength)}
                    </td>
                    <td className="py-2.5 px-3 tabular-nums">{s.trouserWaist}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Measuring Tips */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 my-5 text-xs text-stone-600 bg-stone-50 p-4 rounded-xl border border-stone-200">
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-stone-800">Chest Measurement:</strong> Measure horizontally around the fullest part of your chest with a relaxed tape.
            </div>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-stone-800">Shirt Length:</strong> From highest point of shoulder down to your desired hemline.
            </div>
          </div>
        </div>

        {/* Custom Tailoring Form */}
        <div className="p-4 bg-amber-50/80 rounded-xl border border-amber-200">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="font-semibold text-stone-900 text-sm">
                Need a Custom Made-to-Measure Fit?
              </h3>
              <p className="text-xs text-stone-600">
                Our Karachi CMT unit stitches custom lengths and cuts with no extra hidden charges.
              </p>
            </div>
          </div>

          <form onSubmit={handleSendCustomInquiry} className="grid grid-cols-1 sm:grid-cols-4 gap-2 mt-3">
            <input
              type="text"
              placeholder="Your Name"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              className="px-3 py-1.5 bg-white border border-stone-300 rounded text-xs"
              required
            />
            <input
              type="text"
              placeholder='Desired Length (e.g. 42")'
              value={customLength}
              onChange={(e) => setCustomLength(e.target.value)}
              className="px-3 py-1.5 bg-white border border-stone-300 rounded text-xs"
            />
            <input
              type="text"
              placeholder='Desired Chest (e.g. 40")'
              value={customChest}
              onChange={(e) => setCustomChest(e.target.value)}
              className="px-3 py-1.5 bg-white border border-stone-300 rounded text-xs"
            />
            <button
              type="submit"
              className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>Send via WhatsApp</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
