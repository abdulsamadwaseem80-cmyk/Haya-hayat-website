import React, { useState } from 'react';
import { ArrowRight, Sparkles, ShieldCheck, Truck, Clock, Instagram, Palette } from 'lucide-react';
import { INSTAGRAM_ORDER_URL } from '../data/products';
import { resolveImage, handleImageError } from '../utils/images';

interface HeroSectionProps {
  onShopClick: () => void;
  onOpenCustomSizing: () => void;
  onOpenCustomColorStudio?: () => void;
}

const HERO_LOOKS = [
  {
    id: 'sage-tassel',
    title: 'Pistachio Sage 2-Piece Tassel & Pearl Co-ord',
    badge: 'New Arrival ✨ University & Pret Staple',
    caption: 'Handcrafted pearl loop neckline with silk tassel drop & matching straight trousers',
    price: 'Rs. 3,250',
    image: resolveImage('/src/assets/images/sage_coord_set_1790268404551.jpg'),
    colorHex: '#8A9A86',
    colorName: 'Pistachio Sage'
  },
  {
    id: 'plum-solid',
    title: 'Solid 2-Piece Pearl Flare Plum Co-ord',
    badge: 'Favorite Color Drop ✨ University & Workwear',
    caption: 'customize in your favorite color✨🫶🏻 · Affordable workwear & university girl outfit',
    price: 'Rs. 3,250',
    image: resolveImage('/src/assets/images/plum_coord_set_1790262536094.jpg'),
    colorHex: '#4A1D34',
    colorName: 'Deep Plum'
  },
  {
    id: 'gota-navy',
    title: 'Noor Navy Gold Gota-Patti Festive 2-Piece',
    badge: 'Festive Arrival ✨ Gota Collection',
    caption: 'Kalidar frock kurti with artisanal geometric ivory trousers',
    price: 'Rs. 3,950',
    image: resolveImage('/src/assets/images/gota_navy_festive_1790262572910.jpg'),
    colorHex: '#1B365D',
    colorName: 'Royal Navy'
  },
  {
    id: 'sage-linen',
    title: 'Sage Whisper Washed Linen Co-ord',
    badge: 'Signature Cutwork Staple',
    caption: 'Pure organic washed linen with breathable modest drop-shoulder cut',
    price: 'Rs. 3,850',
    image: resolveImage('/src/assets/images/hero_modest_fashion_1790260531937.jpg'),
    colorHex: '#8A9A86',
    colorName: 'Sage Mist'
  }
];

export const HeroSection: React.FC<HeroSectionProps> = ({
  onShopClick,
  onOpenCustomSizing,
  onOpenCustomColorStudio,
}) => {
  const [activeLookIndex, setActiveLookIndex] = useState<number>(0);
  const currentLook = HERO_LOOKS[activeLookIndex];

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-[#F7F4EE] to-[#FAF9F6] border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-14 lg:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Editorial Headline & Value Propositions */}
          <div className="lg:col-span-6 flex flex-col justify-center space-y-6">
            <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-stone-600 bg-amber-50/80 border border-amber-200/80 px-3 py-1.5 rounded-full w-fit">
              <span className="w-2 h-2 rounded-full bg-rose-600 animate-pulse"></span>
              <span className="text-stone-800 font-bold tracking-normal">
                customize in your favorite color✨🫶🏻
              </span>
            </div>

            <div className="space-y-3">
              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-medium tracking-tight text-stone-900 leading-[1.12] text-balance">
                Modesty Tailored in Your Favorite Shade
              </h1>
              <p className="text-base sm:text-lg text-stone-600 leading-relaxed max-w-xl">
                Curated by <strong className="text-stone-900 font-semibold">Haya-e-Hayat</strong> (@hayaehayat). 
                Solid 2-piece pearl flare cordsets customized in your bespoke color, affordable workwear for university girls & professionals, and regal festive gota pret.
              </p>
            </div>

            {/* Promotional callout box */}
            <div className="p-3.5 bg-stone-100/90 rounded-xl border border-stone-200/80 flex items-center justify-between gap-4 max-w-md">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-[#CBB593]/20 flex items-center justify-center text-stone-800 shrink-0">
                  <Sparkles className="w-4 h-4 text-[#8A6A3F]" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-stone-900">Customize Any Color & Size</div>
                  <div className="text-[11px] text-stone-500">Bespoke dyeing & tailoring at our Karachi atelier</div>
                </div>
              </div>
              <span className="px-2.5 py-1 bg-white border border-stone-300 font-mono text-xs font-bold text-stone-800 rounded shadow-xs tracking-wider">
                HAYA10
              </span>
            </div>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              {onOpenCustomColorStudio && (
                <button
                  onClick={onOpenCustomColorStudio}
                  className="flex items-center gap-2 px-5 py-3.5 bg-gradient-to-r from-stone-900 via-rose-950 to-stone-900 text-stone-50 text-sm font-semibold rounded-lg hover:opacity-95 transition-all shadow-md group cursor-pointer"
                >
                  <Palette className="w-4 h-4 text-amber-300" />
                  <span>Customize in Your Color ✨</span>
                </button>
              )}

              <button
                onClick={onShopClick}
                className="flex items-center gap-2 px-5 py-3.5 bg-white border border-stone-300 text-stone-900 text-sm font-semibold rounded-lg hover:border-stone-400 hover:bg-stone-50 transition-all shadow-xs cursor-pointer"
              >
                <span>Explore Designs</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <a
                href={INSTAGRAM_ORDER_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-3.5 rounded-lg border border-pink-300 bg-gradient-to-r from-pink-50 via-rose-50 to-amber-50 hover:from-pink-100 hover:to-rose-100 text-stone-900 text-sm font-semibold transition-all shadow-xs"
              >
                <Instagram className="w-4 h-4 text-pink-600" />
                <span>DM to Order</span>
              </a>
            </div>

            {/* Trust Markers Bar */}
            <div className="grid grid-cols-3 gap-3 pt-4 border-t border-stone-200/80 text-xs text-stone-600">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-emerald-700 shrink-0" />
                <span className="font-medium text-stone-800">Free Delivery in All Over Pakistan</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>Pre-Shrunk 100% Pure Fabrics</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>Custom Sizing & Fast Dispatch</span>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual Asset with Interactive Look Switcher */}
          <div className="lg:col-span-6 space-y-4">
            <div className="relative rounded-2xl overflow-hidden shadow-xl aspect-16/10 lg:aspect-4/3 bg-stone-200 border border-stone-300/60">
              <img
                src={currentLook.image}
                alt={currentLook.title}
                referrerPolicy="no-referrer"
                loading="eager"
                fetchPriority="high"
                decoding="async"
                className="w-full h-full object-cover object-center transform hover:scale-103 transition-transform duration-700"
                onError={handleImageError}
              />
              
              {/* Overlay Badge */}
              <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-white/95 backdrop-blur-md border border-white/70 shadow-lg flex items-center justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-stone-600">
                    <span className="w-2 h-2 rounded-full bg-pink-600 animate-ping"></span>
                    <span>{currentLook.badge}</span>
                  </div>
                  <div className="font-serif text-base sm:text-lg font-bold text-stone-900 truncate">
                    {currentLook.title}
                  </div>
                  <div className="text-xs text-stone-500 font-medium">
                    {currentLook.price} · <span className="text-stone-700">{currentLook.caption}</span>
                  </div>
                </div>
                <button
                  onClick={onShopClick}
                  className="px-3.5 py-2 bg-stone-900 hover:bg-stone-800 text-stone-50 text-xs font-semibold rounded-lg transition-colors shrink-0 shadow-xs cursor-pointer"
                >
                  Shop Now
                </button>
              </div>

              {/* Subtle decorative authentic stitch emblem */}
              <div className="hidden sm:flex absolute top-3 right-3 bg-stone-900/90 backdrop-blur-xs text-[#E4D5BE] px-3 py-1.5 rounded-full shadow-md items-center justify-center text-center">
                <span className="font-serif text-[11px] font-semibold tracking-wider">
                  @hayaehayat Original
                </span>
              </div>
            </div>

            {/* Quick Switcher Thumbnails */}
            <div className="flex items-center justify-between gap-3 px-1">
              <div className="text-xs text-stone-500 font-medium">
                Featured Styles:
              </div>
              <div className="flex items-center gap-2">
                {HERO_LOOKS.map((look, idx) => (
                  <button
                    key={look.id}
                    onClick={() => setActiveLookIndex(idx)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer border ${
                      activeLookIndex === idx
                        ? 'border-stone-900 bg-stone-900 text-white shadow-xs'
                        : 'border-stone-300 bg-white text-stone-700 hover:border-stone-400'
                    }`}
                  >
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0 border border-white/40"
                      style={{ backgroundColor: look.colorHex }}
                    />
                    <span>{look.colorName}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
