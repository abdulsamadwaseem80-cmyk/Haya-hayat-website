import React, { useState } from 'react';
import { X, Sparkles, Check, ShoppingBag, Instagram, MessageCircle, Ruler, ShieldCheck, Heart, Palette, Sliders, ChevronRight } from 'lucide-react';
import { Product, CORDSET_CUSTOM_COLORS, ProductColorOption, INSTAGRAM_ORDER_URL, INSTAGRAM_HANDLE } from '../data/products';
import { Currency, CartItem } from '../types';
import { formatPrice } from '../utils/format';
import { handleImageError } from '../utils/images';

interface CustomColorModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: Product;
  currency: Currency;
  onAddToCart: (
    product: Product,
    size: 'XS' | 'S' | 'M' | 'L' | 'XL' | 'Custom',
    customColor?: {
      name: string;
      hex: string;
      neckline?: string;
      shirtLength?: string;
      trouserStyle?: string;
      isCustomToned?: boolean;
    },
    customMeasurements?: {
      shirtLength?: string;
      chest?: string;
      trouserLength?: string;
      additionalNote?: string;
    }
  ) => void;
  onOpenSizeGuide: () => void;
}

export const CustomColorModal: React.FC<CustomColorModalProps> = ({
  isOpen,
  onClose,
  product,
  currency,
  onAddToCart,
  onOpenSizeGuide
}) => {
  const [selectedColor, setSelectedColor] = useState<ProductColorOption>(CORDSET_CUSTOM_COLORS[0]);
  const [isCustomPicker, setIsCustomPicker] = useState(false);
  const [customColorHex, setCustomColorHex] = useState('#8A9A86');
  const [customColorName, setCustomColorName] = useState('');
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<'All' | 'Popular' | 'Pastel' | 'Neutral' | 'Jewel Tone'>('All');

  const [selectedSize, setSelectedSize] = useState<'XS' | 'S' | 'M' | 'L' | 'XL' | 'Custom'>('M');
  const [necklineStyle, setNecklineStyle] = useState<'Double-Row Pearls' | 'Single-Row Pearls' | 'Clean Minimalist'>('Double-Row Pearls');
  const [tunicLength, setTunicLength] = useState<'38" Standard' | '42" Modest Long' | 'Custom'>('38" Standard');
  const [trouserStyle, setTrouserStyle] = useState<'Flared Palazzo' | 'Straight Trouser' | 'Relaxed Culottes'>('Flared Palazzo');

  const [customChest, setCustomChest] = useState('');
  const [customLengthInput, setCustomLengthInput] = useState('');
  const [customTrouserInput, setCustomTrouserInput] = useState('');
  const [customNote, setCustomNote] = useState('');

  const [addedSuccess, setAddedSuccess] = useState(false);
  const [copiedForIg, setCopiedForIg] = useState(false);

  if (!isOpen) return null;

  const effectiveColorName = isCustomPicker 
    ? (customColorName.trim() || 'Bespoke Custom Shade') 
    : selectedColor.name;

  const effectiveColorHex = isCustomPicker ? customColorHex : selectedColor.hex;

  const filteredColors = activeCategoryFilter === 'All'
    ? CORDSET_CUSTOM_COLORS
    : CORDSET_CUSTOM_COLORS.filter(c => c.category === activeCategoryFilter);

  const buildSummaryText = () => {
    return `Assalam o Alaikum Haya-e-Hayat! 
I would like to customize the Solid 2-Piece Cordset in my favorite color:
• Color: ${effectiveColorName} (${effectiveColorHex})
• Size: ${selectedSize}
• Neckline: ${necklineStyle}
• Tunic Length: ${tunicLength === 'Custom' ? customLengthInput || 'Custom' : tunicLength}
• Trouser Cut: ${trouserStyle}
${selectedSize === 'Custom' ? `• Custom Measurements: Chest ${customChest || '-'}, Length ${customLengthInput || '-'}, Trouser ${customTrouserInput || '-'}` : ''}
${customNote ? `• Note: ${customNote}` : ''}
• Price: Rs. ${product.pricePKR}`;
  };

  const handleInstagramOrder = () => {
    const text = buildSummaryText();
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(text).catch(() => {});
      setCopiedForIg(true);
      setTimeout(() => setCopiedForIg(false), 3000);
    }
    window.open(INSTAGRAM_ORDER_URL, '_blank');
  };

  const handleWhatsAppOrder = () => {
    const text = buildSummaryText();
    const encoded = encodeURIComponent(text);
    window.open(`https://wa.me/923214292328?text=${encoded}`, '_blank');
  };

  const handleAddToCart = () => {
    onAddToCart(
      product,
      selectedSize,
      {
        name: effectiveColorName,
        hex: effectiveColorHex,
        neckline: necklineStyle,
        shirtLength: tunicLength === 'Custom' ? customLengthInput : tunicLength,
        trouserStyle: trouserStyle,
        isCustomToned: true
      },
      selectedSize === 'Custom' ? {
        shirtLength: customLengthInput,
        chest: customChest,
        trouserLength: customTrouserInput,
        additionalNote: customNote
      } : undefined
    );

    setAddedSuccess(true);
    setTimeout(() => {
      setAddedSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/75 backdrop-blur-sm overflow-y-auto">
      <div 
        className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl overflow-hidden my-6 border border-stone-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 sm:px-7 py-4 bg-[#F8F6F2] border-b border-stone-200">
          <div className="flex items-center gap-2.5">
            <span className="p-2 bg-amber-100 text-amber-900 rounded-lg">
              <Palette className="w-5 h-5" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-serif text-lg sm:text-xl font-semibold text-stone-900">
                  Customize in Your Favorite Color✨🫶🏻
                </h2>
                <span className="hidden sm:inline-block text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 bg-rose-900 text-rose-100 rounded">
                  Bespoke Dyeing
                </span>
              </div>
              <p className="text-xs text-stone-600">
                Solid 2-piece, affordable workwear, university girl outfit with signature pearl neckline
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 bg-white hover:bg-stone-200 text-stone-700 rounded-full transition-colors cursor-pointer border border-stone-200"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="grid grid-cols-1 md:grid-cols-12 max-h-[80vh] overflow-y-auto">
          {/* Left Column: Interactive Visual Preview */}
          <div className="md:col-span-5 bg-gradient-to-b from-[#FAF8F5] to-[#F2EFE9] p-5 sm:p-6 flex flex-col justify-between border-b md:border-b-0 md:border-r border-stone-200">
            <div>
              {/* Product Visual Container */}
              <div className="relative aspect-4/5 w-full rounded-xl overflow-hidden bg-stone-100 shadow-sm border border-stone-200">
                <img
                  src={product.image}
                  alt={product.name}
                  referrerPolicy="no-referrer"
                  loading="lazy"
                  decoding="async"
                  className="w-full h-full object-cover object-center"
                  onError={handleImageError}
                />

                {/* Dynamic Hue Tint Overlay to simulate chosen color */}
                <div 
                  className="absolute inset-0 mix-blend-color opacity-75 pointer-events-none transition-colors duration-500"
                  style={{ backgroundColor: effectiveColorHex }}
                />

                {/* Subtle sheen layer */}
                <div 
                  className="absolute inset-0 mix-blend-multiply opacity-25 pointer-events-none transition-colors duration-500"
                  style={{ backgroundColor: effectiveColorHex }}
                />

                {/* Live Color Badge */}
                <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-stone-900/90 backdrop-blur-md rounded-lg shadow-sm text-stone-50 text-xs">
                    <span 
                      className="w-3.5 h-3.5 rounded-full border border-white/50 shadow-xs"
                      style={{ backgroundColor: effectiveColorHex }}
                    />
                    <span className="font-medium">{effectiveColorName}</span>
                  </div>

                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-1 bg-white/95 text-stone-900 rounded shadow-xs backdrop-blur-xs">
                    Rs. {product.pricePKR.toLocaleString()}
                  </span>
                </div>

                {/* Pearl details floating callout */}
                <div className="absolute bottom-3 inset-x-3 p-2.5 bg-white/90 backdrop-blur-md rounded-lg text-[11px] text-stone-800 border border-stone-200/80 shadow-xs flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span>Double-row pearl beads hand-embellished</span>
                  </div>
                  <span className="font-serif italic text-stone-500 text-[10px]">Haya e Hayat</span>
                </div>
              </div>

              {/* Swatch info pill */}
              <div className="mt-4 p-3 bg-white rounded-xl border border-stone-200 text-xs space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-stone-500 font-medium">Selected Color:</span>
                  <div className="flex items-center gap-1.5 font-semibold text-stone-900">
                    <span 
                      className="w-3 h-3 rounded-full border border-stone-300"
                      style={{ backgroundColor: effectiveColorHex }}
                    />
                    <span>{effectiveColorName}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between text-[11px] text-stone-500">
                  <span>Hex Reference:</span>
                  <span className="font-mono text-stone-700 uppercase">{effectiveColorHex}</span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-stone-500">
                  <span>Fabric:</span>
                  <span className="text-stone-800 font-medium">Premium Crepe Silk Blend</span>
                </div>
              </div>
            </div>

            {/* Quality Note */}
            <div className="mt-4 p-3 bg-stone-100 rounded-lg text-stone-600 text-[11px] flex items-center gap-2 border border-stone-200">
              <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>Colorfast dyeing in Karachi. Wrinkle-resistant for university & work.</span>
            </div>
          </div>

          {/* Right Column: Interactive Color Palette & Customizer */}
          <div className="md:col-span-7 p-5 sm:p-7 flex flex-col justify-between space-y-6">
            <div className="space-y-5">
              {/* Step 1: Choose Favorite Color */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-stone-800 flex items-center gap-1.5">
                    <span className="w-4 h-4 rounded-full bg-stone-900 text-stone-50 text-[10px] flex items-center justify-center font-bold">1</span>
                    Choose Your Favorite Color:
                  </span>
                  <span className="text-[11px] text-rose-800 font-semibold bg-rose-50 px-2 py-0.5 rounded">
                    12+ Shades Available
                  </span>
                </div>

                {/* Filter Categories */}
                <div className="flex gap-1.5 mb-3 overflow-x-auto pb-1 text-[11px]">
                  {(['All', 'Popular', 'Pastel', 'Neutral', 'Jewel Tone'] as const).map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setActiveCategoryFilter(cat)}
                      className={`px-2.5 py-1 rounded-md whitespace-nowrap transition-colors cursor-pointer ${
                        activeCategoryFilter === cat && !isCustomPicker
                          ? 'bg-stone-900 text-stone-50 font-medium'
                          : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                  <button
                    onClick={() => setIsCustomPicker(true)}
                    className={`px-2.5 py-1 rounded-md whitespace-nowrap transition-colors flex items-center gap-1 cursor-pointer ${
                      isCustomPicker
                        ? 'bg-gradient-to-r from-amber-600 to-rose-600 text-white font-medium shadow-xs'
                        : 'bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100'
                    }`}
                  >
                    <Palette className="w-3 h-3" />
                    <span>Custom Shade ✨</span>
                  </button>
                </div>

                {/* Swatches Grid */}
                {!isCustomPicker ? (
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                    {filteredColors.map((color) => {
                      const isSelected = selectedColor.name === color.name && !isCustomPicker;
                      return (
                        <button
                          key={color.name}
                          onClick={() => {
                            setSelectedColor(color);
                            setIsCustomPicker(false);
                          }}
                          className={`p-2 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer relative ${
                            isSelected
                              ? 'border-stone-900 bg-stone-50 shadow-sm ring-1 ring-stone-900'
                              : 'border-stone-200 hover:border-stone-400 bg-white'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1.5">
                            <span 
                              className="w-5 h-5 rounded-full border border-stone-300/80 shadow-xs shrink-0"
                              style={{ backgroundColor: color.hex }}
                            />
                            {isSelected && (
                              <Check className="w-3.5 h-3.5 text-stone-900" />
                            )}
                          </div>
                          <div>
                            <div className="text-[11px] font-semibold text-stone-900 leading-tight">
                              {color.name}
                            </div>
                            {color.urduName && (
                              <div className="text-[10px] font-serif text-stone-400">
                                {color.urduName}
                              </div>
                            )}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  /* Custom Shade Input Section */
                  <div className="p-4 bg-amber-50/50 rounded-xl border border-amber-200 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-amber-950">
                        Select Custom Tone & Name:
                      </span>
                      <button
                        onClick={() => setIsCustomPicker(false)}
                        className="text-[11px] text-stone-600 hover:text-stone-900 underline cursor-pointer"
                      >
                        Back to Palette
                      </button>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <input
                          type="color"
                          value={customColorHex}
                          onChange={(e) => setCustomColorHex(e.target.value)}
                          className="w-12 h-12 rounded-xl border-2 border-amber-300 p-0.5 cursor-pointer bg-white"
                          title="Click to pick custom color tone"
                        />
                      </div>

                      <div className="flex-1">
                        <label className="text-[11px] text-stone-600 block mb-1">
                          Custom Color Name or Description
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. Pistachio Green, Dusty Lavender, Steel Blue..."
                          value={customColorName}
                          onChange={(e) => setCustomColorName(e.target.value)}
                          className="w-full px-3 py-1.5 bg-white border border-stone-300 rounded-lg text-xs focus:ring-1 focus:ring-stone-900 focus:outline-none"
                        />
                      </div>
                    </div>
                    <p className="text-[11px] text-stone-500">
                      💡 We match your shade using precision CMT fabric dyeing. You can also send an Instagram photo for reference!
                    </p>
                  </div>
                )}
              </div>

              {/* Step 2: Neckline & Styling Options */}
              <div className="pt-2 border-t border-stone-200">
                <span className="text-xs font-bold uppercase tracking-wider text-stone-800 flex items-center gap-1.5 mb-2">
                  <span className="w-4 h-4 rounded-full bg-stone-900 text-stone-50 text-[10px] flex items-center justify-center font-bold">2</span>
                  Neckline & Fit Preferences:
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                  {/* Neckline */}
                  <div>
                    <label className="text-[11px] font-medium text-stone-600 block mb-1">Neckline Detail</label>
                    <select
                      value={necklineStyle}
                      onChange={(e) => setNecklineStyle(e.target.value as any)}
                      className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs"
                    >
                      <option value="Double-Row Pearls">Signature Double Pearls</option>
                      <option value="Single-Row Pearls">Single-Row Pearl Bead</option>
                      <option value="Clean Minimalist">Clean Plain (No Pearls)</option>
                    </select>
                  </div>

                  {/* Shirt Length */}
                  <div>
                    <label className="text-[11px] font-medium text-stone-600 block mb-1">Tunic Length</label>
                    <select
                      value={tunicLength}
                      onChange={(e) => setTunicLength(e.target.value as any)}
                      className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs"
                    >
                      <option value='38" Standard'>38" Standard Knee</option>
                      <option value='42" Modest Long'>42" Modest Long Flare</option>
                      <option value="Custom">Custom Length</option>
                    </select>
                  </div>

                  {/* Trouser Style */}
                  <div>
                    <label className="text-[11px] font-medium text-stone-600 block mb-1">Trouser Style</label>
                    <select
                      value={trouserStyle}
                      onChange={(e) => setTrouserStyle(e.target.value as any)}
                      className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs"
                    >
                      <option value="Flared Palazzo">Wide-Leg Flared Palazzo</option>
                      <option value="Straight Trouser">Straight-Cut Cigarette</option>
                      <option value="Relaxed Culottes">Relaxed Modest Culottes</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Step 3: Size & Custom Sizing */}
              <div className="pt-2 border-t border-stone-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-stone-800 flex items-center gap-1.5">
                    <span className="w-4 h-4 rounded-full bg-stone-900 text-stone-50 text-[10px] flex items-center justify-center font-bold">3</span>
                    Select Size:
                  </span>
                  <button
                    onClick={onOpenSizeGuide}
                    className="text-xs text-stone-600 hover:text-stone-900 flex items-center gap-1 underline underline-offset-2 cursor-pointer"
                  >
                    <Ruler className="w-3.5 h-3.5 text-stone-700" />
                    <span>View Size Chart</span>
                  </button>
                </div>

                <div className="grid grid-cols-6 gap-2">
                  {(['XS', 'S', 'M', 'L', 'XL', 'Custom'] as const).map((sz) => (
                    <button
                      key={sz}
                      onClick={() => setSelectedSize(sz)}
                      className={`py-2 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                        selectedSize === sz
                          ? 'border-stone-900 bg-stone-900 text-stone-50 shadow-xs'
                          : 'border-stone-200 bg-white text-stone-700 hover:border-stone-400'
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>

                {/* Custom Sizing Drawer if Custom Size */}
                {selectedSize === 'Custom' && (
                  <div className="mt-3 p-3 bg-amber-50/70 rounded-xl border border-amber-200 text-xs space-y-2">
                    <div className="font-semibold text-amber-900">
                      Bespoke Tailoring Details (Inches):
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <label className="text-[11px] text-amber-800">Shirt Length</label>
                        <input
                          type="text"
                          placeholder='e.g. 42"'
                          value={customLengthInput}
                          onChange={(e) => setCustomLengthInput(e.target.value)}
                          className="w-full mt-0.5 px-2 py-1 bg-white border border-amber-300 rounded text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] text-amber-800">Chest Size</label>
                        <input
                          type="text"
                          placeholder='e.g. 40"'
                          value={customChest}
                          onChange={(e) => setCustomChest(e.target.value)}
                          className="w-full mt-0.5 px-2 py-1 bg-white border border-amber-300 rounded text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] text-amber-800">Trouser Length</label>
                        <input
                          type="text"
                          placeholder='e.g. 39"'
                          value={customTrouserInput}
                          onChange={(e) => setCustomTrouserInput(e.target.value)}
                          className="w-full mt-0.5 px-2 py-1 bg-white border border-amber-300 rounded text-xs"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="text-[11px] text-amber-800">Special Notes</label>
                      <input
                        type="text"
                        placeholder="e.g. Extra sleeve cuff length, closed neckline..."
                        value={customNote}
                        onChange={(e) => setCustomNote(e.target.value)}
                        className="w-full mt-0.5 px-2 py-1 bg-white border border-amber-300 rounded text-xs"
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="space-y-2.5 pt-4 border-t border-stone-200">
              {/* Primary Add to Bag */}
              <button
                onClick={handleAddToCart}
                className={`w-full py-3 px-4 rounded-xl font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  addedSuccess
                    ? 'bg-emerald-700 text-white'
                    : 'bg-stone-900 hover:bg-stone-800 text-stone-50 shadow-md'
                }`}
              >
                {addedSuccess ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Added Custom Set in {effectiveColorName} to Bag!</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4 text-stone-300" />
                    <span>Add to Bag in {effectiveColorName} · {formatPrice(product.pricePKR, currency)}</span>
                  </>
                )}
              </button>

              {/* DM on Instagram to Order */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  onClick={handleInstagramOrder}
                  className="py-2.5 px-3 bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#FCB045] hover:opacity-95 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 shadow-xs transition-opacity cursor-pointer"
                  title="DM your chosen color to @hayaehayat on Instagram"
                >
                  <Instagram className="w-4 h-4 shrink-0" />
                  <span className="truncate">
                    {copiedForIg ? 'Color Copied! Opening Instagram DM...' : 'DM on Instagram to Order ✨'}
                  </span>
                </button>

                <button
                  onClick={handleWhatsAppOrder}
                  className="py-2.5 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span className="truncate">WhatsApp Custom Order</span>
                </button>
              </div>

              <div className="text-center text-[11px] font-medium text-emerald-800 bg-emerald-50/80 py-1.5 px-3 rounded-lg border border-emerald-200">
                ✨ Free Delivery in All Over Pakistan · Cash on Delivery (COD) · 7-Day Exchange
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
