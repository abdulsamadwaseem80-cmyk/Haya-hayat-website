import React from 'react';
import { Instagram, Phone, Globe } from 'lucide-react';
import { Currency } from '../types';

interface AnnouncementBarProps {
  currency: Currency;
  onCurrencyChange: (c: Currency) => void;
  onOpenSizeGuide: () => void;
  onOpenCustomColorStudio?: () => void;
}

export const AnnouncementBar: React.FC<AnnouncementBarProps> = ({
  currency,
  onCurrencyChange,
  onOpenSizeGuide,
  onOpenCustomColorStudio,
}) => {
  return (
    <div className="bg-[#2B2825] text-[#ECE7DF] text-xs py-2 px-4 border-b border-[#3D3833]">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
        {/* Left: Instagram & WhatsApp Trust Links */}
        <div className="flex items-center gap-4 text-[11px] tracking-wide">
          <a
            href="https://www.instagram.com/hayaehayat?stkn=MXIwZHJsNngzdWpwYQ=="
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-[#D1C7B7] hover:text-white transition-colors"
          >
            <Instagram className="w-3.5 h-3.5 text-[#E3B899]" />
            <span className="font-medium">DM on Instagram to Order @hayaehayat</span>
          </a>
          <span className="text-stone-600 hidden md:inline">|</span>
          {onOpenCustomColorStudio && (
            <button
              onClick={onOpenCustomColorStudio}
              className="hidden sm:inline-flex items-center gap-1 text-amber-200 hover:text-amber-100 transition-colors cursor-pointer"
            >
              <span>✨ Customize in your favorite color🫶🏻</span>
            </button>
          )}
        </div>

        {/* Center: Delivery Notice */}
        <div className="text-center font-medium tracking-wide text-[#EADFCB] flex items-center justify-center gap-1.5">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-semibold text-emerald-200">Free Delivery in All Over Pakistan</span>
          <span className="hidden sm:inline text-stone-500 mx-1.5">·</span>
          <span className="hidden sm:inline text-[#D1C7B7]">Cash on Delivery (COD)</span>
        </div>

        {/* Right: Sizing consultation & Currency */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenSizeGuide}
            className="text-[11px] text-[#D1C7B7] hover:text-white underline underline-offset-2 transition-colors cursor-pointer"
          >
            Custom Sizing Guide
          </button>
          
          <div className="flex items-center gap-1 text-[11px] bg-[#3B3630] rounded px-1.5 py-0.5 border border-stone-700">
            <Globe className="w-3 h-3 text-stone-400" />
            <button
              onClick={() => onCurrencyChange('PKR')}
              className={`px-1 rounded font-medium transition-colors ${
                currency === 'PKR' ? 'text-amber-200 font-semibold' : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              PKR
            </button>
            <span className="text-stone-600">/</span>
            <button
              onClick={() => onCurrencyChange('USD')}
              className={`px-1 rounded font-medium transition-colors ${
                currency === 'USD' ? 'text-amber-200 font-semibold' : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              USD
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
