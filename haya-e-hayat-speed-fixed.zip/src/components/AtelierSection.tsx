import React from 'react';
import { MapPin, Clock, Phone, Mail, ShieldCheck, Sparkles, Truck, RefreshCw, Instagram } from 'lucide-react';

export const AtelierSection: React.FC = () => {
  return (
    <section id="about" className="py-16 sm:py-24 bg-white border-t border-stone-200 scroll-mt-20">
      <div id="atelier" className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: The Brand Story */}
          <div className="lg:col-span-6 space-y-6">
            <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-stone-500">
              <Sparkles className="w-3.5 h-3.5 text-amber-700" />
              <span>About Us · Our Philosophy</span>
            </div>

            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-medium text-stone-900 leading-tight">
              About Haya-e-Hayat
            </h2>

            <div className="space-y-4 text-sm sm:text-base text-stone-700 leading-relaxed">
              <p className="font-serif text-base sm:text-lg text-stone-900 leading-snug italic border-l-3 border-stone-800 pl-4 py-1.5 bg-[#FAF9F6] rounded-r-xl">
                "Welcome to Haya e Hayat, where timeless elegance meets modern sophistication. Founded on the belief that modesty is an expression of grace and self-assurance, our clothing is crafted for the contemporary individual who values both tradition and style."
              </p>
              <p>
                At Haya e Hayat, every piece tells a story of refined craftsmanship. We source premium fabrics and blend classic cuts with modern trends to create attire that feels luxurious, comfortable, and empowering. Whether for daily wear or memorable occasions, our collections are designed to reflect modesty as a lifestyle—celebrating dignity, beauty, and individuality in every thread.
              </p>
              <p className="text-xs text-stone-500 pt-1">
                Founded on Instagram (<a href="https://www.instagram.com/hayaehayat?stkn=MXIwZHJsNngzdWpwYQ==" target="_blank" rel="noopener noreferrer" className="text-stone-900 font-semibold underline">@hayaehayat</a>) and operating our dedicated CMT stitching unit in Karachi, we inspect every garment for clean stitching, accurate threadwork, pre-shrunk softness, and custom measurements.
              </p>
            </div>

            {/* Feature highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-xl bg-[#FAF9F6] border border-stone-200">
                <div className="font-semibold text-stone-900 text-sm flex items-center gap-2 mb-1">
                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                  <span>Custom Stitching Unit</span>
                </div>
                <p className="text-xs text-stone-500 leading-relaxed">
                  Need a longer shirt, loose chest fit, or custom trouser length? We tailor directly to your individual measurements.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#FAF9F6] border border-stone-200">
                <div className="font-semibold text-stone-900 text-sm flex items-center gap-2 mb-1">
                  <RefreshCw className="w-4 h-4 text-emerald-700" />
                  <span>7-Day Hassle-Free Exchange</span>
                </div>
                <p className="text-xs text-stone-500 leading-relaxed">
                  If you need a different size or adjustment, our responsive team handles exchanges swiftly without complicated hurdles.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Google Business Profile Details Card */}
          <div className="lg:col-span-6 bg-[#FAF9F6] rounded-3xl p-6 sm:p-8 border border-stone-300/80 shadow-md">
            <div className="border-b border-stone-200 pb-5 mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-stone-500">
                    Google Business Profile Information
                  </span>
                  <h3 className="font-serif text-2xl font-bold text-stone-900 mt-0.5">
                    Haya-e-Hayat Apparel & Stitching Unit
                  </h3>
                </div>
                <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 text-xs font-semibold rounded-full flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                  Verified Business
                </span>
              </div>
            </div>

            <div className="space-y-4 text-xs sm:text-sm">
              {/* Location */}
              <div className="flex items-start gap-3.5">
                <div className="w-8 h-8 rounded-lg bg-stone-200/80 flex items-center justify-center shrink-0 text-stone-700 mt-0.5">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-semibold text-stone-900">Karachi CMT Stitching Unit</div>
                  <div className="text-stone-500 text-xs mt-0.5 leading-relaxed">
                    Industrial & Apparel Textile Hub, Karachi, Sindh, Pakistan.<br />
                    (Dispatch headquarters for nationwide courier logistics)
                  </div>
                </div>
              </div>

              {/* Working Hours */}
              <div className="flex items-start gap-3.5">
                <div className="w-8 h-8 rounded-lg bg-stone-200/80 flex items-center justify-center shrink-0 text-stone-700 mt-0.5">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-semibold text-stone-900">Operating & Stitching Hours</div>
                  <div className="text-stone-500 text-xs mt-0.5">
                    Monday to Saturday: 10:00 AM – 9:00 PM (PKT)<br />
                    Sunday: Online WhatsApp Inquiries & Order Processing
                  </div>
                </div>
              </div>

              {/* Direct Phone & WhatsApp */}
              <div className="flex items-start gap-3.5">
                <div className="w-8 h-8 rounded-lg bg-stone-200/80 flex items-center justify-center shrink-0 text-stone-700 mt-0.5">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-semibold text-stone-900">Direct Customer Care & Orders</div>
                  <div className="text-stone-500 text-xs mt-0.5">
                    WhatsApp Hotline: <a href="https://wa.me/923214292328" className="text-emerald-700 font-semibold hover:underline">+92 321 4292328</a>
                  </div>
                </div>
              </div>

              {/* Delivery coverage */}
              <div className="flex items-start gap-3.5">
                <div className="w-8 h-8 rounded-lg bg-stone-200/80 flex items-center justify-center shrink-0 text-stone-700 mt-0.5">
                  <Truck className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-semibold text-stone-900">Free Delivery in All Over Pakistan</div>
                  <div className="text-stone-500 text-xs mt-0.5 leading-relaxed">
                    Enjoy 100% Free Shipping to Karachi, Lahore, Islamabad, Rawalpindi, Faisalabad, Multan, Peshawar, Quetta & all towns in Pakistan! Dispatch with Cash on Delivery (COD) via Trax, TCS, Leopard & PostEx.
                  </div>
                </div>
              </div>
            </div>

            {/* Quick action buttons */}
            <div className="mt-8 pt-6 border-t border-stone-200 flex flex-wrap gap-3">
              <a
                href="https://wa.me/923214292328?text=Hello%20Haya-e-Hayat!%20I%20saw%20your%20business%20profile%20and%20would%20like%20to%20place%20an%20order"
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-3 px-4 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold text-center transition-colors shadow-xs"
              >
                Chat on WhatsApp Now
              </a>

              <a
                href="https://www.instagram.com/hayaehayat?stkn=MXIwZHJsNngzdWpwYQ=="
                target="_blank"
                rel="noopener noreferrer"
                className="py-3 px-4 bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#FCB045] hover:opacity-95 text-white rounded-xl text-xs font-semibold text-center transition-opacity flex items-center justify-center gap-2 shadow-xs"
              >
                <Instagram className="w-4 h-4" />
                <span>DM on Instagram to Order (@hayaehayat)</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
