import React, { useState, useMemo } from 'react';
import { Search, X, ArrowRight } from 'lucide-react';
import { Product, PRODUCTS } from '../data/products';
import { Currency } from '../types';
import { formatPrice } from '../utils/format';
import { handleImageError } from '../utils/images';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  currency: Currency;
  onSelectProduct: (product: Product) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  currency,
  onSelectProduct,
}) => {
  const [query, setQuery] = useState('');

  const filteredProducts = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return PRODUCTS.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        (p.urduName && p.urduName.includes(q)) ||
        p.categoryLabel.toLowerCase().includes(q) ||
        p.fabric.toLowerCase().includes(q) ||
        p.color.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q)
    );
  }, [query]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 pt-16 sm:pt-24 bg-stone-900/60 backdrop-blur-xs">
      <div 
        className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden border border-stone-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="p-4 sm:p-5 border-b border-stone-200 flex items-center gap-3 bg-[#F8F6F1]">
          <Search className="w-5 h-5 text-stone-500" />
          <input
            type="text"
            autoFocus
            placeholder="Search co-ord sets, cutwork, lawn, university outfits, linen..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 bg-transparent text-sm sm:text-base text-stone-900 placeholder:text-stone-400 outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-stone-400 hover:text-stone-700 text-xs px-2 py-1"
            >
              Clear
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 rounded-full hover:bg-stone-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Suggestion Tags */}
        {!query && (
          <div className="p-5 space-y-3">
            <div className="text-xs font-semibold uppercase tracking-wider text-stone-400">
              Popular Searches
            </div>
            <div className="flex flex-wrap gap-2 text-xs">
              {['Sage Linen', 'Cutwork Set', 'University Tunic', 'Emerald Festive', 'Cotton Cambric', '2-Piece Cord'].map(
                (term) => (
                  <button
                    key={term}
                    onClick={() => setQuery(term)}
                    className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg transition-colors cursor-pointer"
                  >
                    {term}
                  </button>
                )
              )}
            </div>
          </div>
        )}

        {/* Results */}
        {query && (
          <div className="max-h-96 overflow-y-auto p-4 divide-y divide-stone-100">
            {filteredProducts.length === 0 ? (
              <div className="py-8 text-center text-xs text-stone-500">
                No matching designs found for "{query}". Try searching "linen", "coord", or "cutwork".
              </div>
            ) : (
              filteredProducts.map((p) => (
                <div
                  key={p.id}
                  onClick={() => {
                    onSelectProduct(p);
                    onClose();
                  }}
                  className="py-3 first:pt-0 flex items-center justify-between gap-4 hover:bg-stone-50 px-2 rounded-lg cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={p.image}
                      alt={p.name}
                      loading="lazy"
                      decoding="async"
                      className="w-12 h-14 object-cover rounded-md border border-stone-200"
                      onError={handleImageError}
                    />
                    <div>
                      <div className="text-xs font-semibold text-stone-900">{p.name}</div>
                      <div className="text-[11px] text-stone-500">{p.fabric} · {p.categoryLabel}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-stone-900 tabular-nums">
                      {formatPrice(p.pricePKR, currency)}
                    </span>
                    <ArrowRight className="w-4 h-4 text-stone-400" />
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};
