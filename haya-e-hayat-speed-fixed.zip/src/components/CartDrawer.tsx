import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, ShieldCheck, Check, MessageCircle, Truck, Instagram } from 'lucide-react';
import { CartItem, Currency, CheckoutFormState, PlacedOrder } from '../types';
import { formatPrice } from '../utils/format';
import { INSTAGRAM_ORDER_URL } from '../data/products';
import { handleImageError } from '../utils/images';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  currency: Currency;
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

const CITIES = [
  'Karachi',
  'Lahore',
  'Islamabad',
  'Rawalpindi',
  'Faisalabad',
  'Multan',
  'Peshawar',
  'Quetta',
  'Sialkot',
  'Hyderabad',
  'Gujranwala',
  'Other / International',
];

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  currency,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [step, setStep] = useState<'cart' | 'checkout' | 'confirmed'>('cart');
  const [couponCode, setCouponCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState<number>(0);
  const [couponMessage, setCouponMessage] = useState<string>('');
  const [placedOrder, setPlacedOrder] = useState<PlacedOrder | null>(null);

  const [formData, setFormData] = useState<CheckoutFormState>({
    fullName: '',
    phone: '',
    email: '',
    address: '',
    city: 'Karachi',
    postalCode: '',
    paymentMethod: 'cod',
    notes: '',
  });

  if (!isOpen) return null;

  const subtotalPKR = items.reduce((acc, item) => acc + item.pricePKR * item.quantity, 0);
  const discountPKR = Math.round(subtotalPKR * (discountPercent / 100));
  // 100% Free Nationwide Delivery across All Over Pakistan
  const shippingPKR = 0;
  const totalPKR = Math.max(0, subtotalPKR - discountPKR + shippingPKR);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (couponCode.trim().toUpperCase() === 'HAYA10') {
      setDiscountPercent(10);
      setCouponMessage('Code HAYA10 applied: 10% Discount!');
    } else {
      setCouponMessage('Invalid code. Use "HAYA10" for 10% off.');
    }
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const orderId = `HH-${Math.floor(1000 + Math.random() * 9000)}`;
    const newOrder: PlacedOrder = {
      orderId,
      items: [...items],
      subtotalPKR,
      discountPKR,
      shippingPKR,
      totalPKR,
      customer: { ...formData },
      date: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      }),
    };

    setPlacedOrder(newOrder);
    setStep('confirmed');
    onClearCart();
  };

  const [copiedCartForIg, setCopiedCartForIg] = useState(false);

  const handleInstagramDirectOrder = () => {
    if (items.length === 0) return;
    const itemsList = items
      .map((it) => `• ${it.product.name} (Size: ${it.size}, Qty: ${it.quantity}) - Rs. ${it.pricePKR * it.quantity}`)
      .join('\n');
    const msg = `Assalam o Alaikum Haya-e-Hayat! I want to place an order via Instagram DM:\n\n*Items:*\n${itemsList}\n\n*Total Payable:* Rs. ${totalPKR} (Free Delivery in All Over Pakistan)\n*Delivery City:* ${formData.city || 'Karachi'}\n\nPlease confirm availability & Cash on Delivery delivery time!`;

    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(msg).catch(() => {});
    }
    setCopiedCartForIg(true);
    setTimeout(() => setCopiedCartForIg(false), 2500);

    window.open(INSTAGRAM_ORDER_URL, '_blank');
  };

  const handleWhatsAppConfirm = () => {
    if (!placedOrder) return;
    const itemsList = placedOrder.items
      .map((it) => `- ${it.product.name} (Size: ${it.size}, Qty: ${it.quantity}) - Rs. ${it.pricePKR * it.quantity}`)
      .join('\n');

    const msg = `*Order Confirmation Request (ID: #${placedOrder.orderId})*\n\n*Customer Details:*\nName: ${placedOrder.customer.fullName}\nPhone: ${placedOrder.customer.phone}\nAddress: ${placedOrder.customer.address}, ${placedOrder.customer.city}\nPayment: ${placedOrder.customer.paymentMethod.toUpperCase()}\n\n*Items:*\n${itemsList}\n\n*Total Payable:* Rs. ${placedOrder.totalPKR}\n\nPlease confirm my order dispatch. Thank you!`;
    window.open(`https://wa.me/923214292328?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const handleInstagramConfirm = () => {
    if (!placedOrder) return;
    const itemsList = placedOrder.items
      .map((it) => `• ${it.product.name}${it.customColor ? ` (Color: ${it.customColor.name})` : ''} (Size: ${it.size}, Qty: ${it.quantity}) - Rs. ${it.pricePKR * it.quantity}`)
      .join('\n');

    const msg = `Assalam o Alaikum Haya-e-Hayat! Here is my Order Confirmation (ID: #${placedOrder.orderId}):\n\nName: ${placedOrder.customer.fullName}\nPhone: ${placedOrder.customer.phone}\nAddress: ${placedOrder.customer.address}, ${placedOrder.customer.city}\nPayment: ${placedOrder.customer.paymentMethod.toUpperCase()}\nTotal: Rs. ${placedOrder.totalPKR}\n\nItems:\n${itemsList}\n\nPlease confirm my dispatch!`;

    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(msg).catch(() => {});
    }
    window.open(INSTAGRAM_ORDER_URL, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-stone-900/60 backdrop-blur-xs flex justify-end">
      <div 
        className="w-full max-w-lg bg-white h-full shadow-2xl flex flex-col justify-between overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Drawer Bar */}
        <div className="p-4 sm:p-5 border-b border-stone-200 flex items-center justify-between bg-[#F8F6F1]">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-stone-800" />
            <span className="font-serif text-lg font-bold text-stone-900">
              {step === 'cart' && `Shopping Bag (${items.reduce((a, b) => a + b.quantity, 0)})`}
              {step === 'checkout' && 'Cash on Delivery Checkout'}
              {step === 'confirmed' && 'Order Placed!'}
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-stone-500 hover:text-stone-900 rounded-full hover:bg-stone-200 transition-colors cursor-pointer"
            aria-label="Close cart"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* STEP 1: CART LIST */}
          {step === 'cart' && (
            <>
              {/* Free Delivery Bar */}
              <div className="p-3.5 bg-emerald-50/90 rounded-xl border border-emerald-200 shadow-xs">
                <div className="flex items-center justify-between text-xs text-emerald-950 font-medium mb-1">
                  <span className="text-emerald-800 font-semibold flex items-center gap-1.5">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Free Delivery in All Over Pakistan!</span>
                  </span>
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full uppercase tracking-wider">
                    Rs. 0 Delivery
                  </span>
                </div>
                <p className="text-[11px] text-emerald-700 leading-snug">
                  Complimentary express delivery across Karachi, Lahore, Islamabad & every city/town in Pakistan with Cash on Delivery (COD).
                </p>
              </div>

              {/* Items List */}
              {items.length === 0 ? (
                <div className="py-16 text-center space-y-3">
                  <div className="w-16 h-16 rounded-full bg-stone-100 flex items-center justify-center mx-auto text-stone-400">
                    <ShoppingBag className="w-8 h-8" />
                  </div>
                  <h3 className="font-serif text-lg font-medium text-stone-800">Your bag is empty</h3>
                  <p className="text-xs text-stone-500 max-w-xs mx-auto">
                    Discover our bestselling modest 2-piece co-ord sets and cutwork pret.
                  </p>
                  <button
                    onClick={onClose}
                    className="mt-2 px-5 py-2.5 bg-stone-900 text-stone-50 rounded-lg text-xs font-semibold hover:bg-stone-800 transition-colors"
                  >
                    Start Shopping
                  </button>
                </div>
              ) : (
                <div className="space-y-4 divide-y divide-stone-100">
                  {items.map((item) => (
                    <div key={item.id} className="pt-4 first:pt-0 flex gap-3 sm:gap-4 items-start">
                      <div className="w-18 h-22 rounded-lg bg-stone-100 overflow-hidden shrink-0 border border-stone-200">
                        <img
                          src={item.product.image}
                          alt={item.product.name}
                          loading="lazy"
                          decoding="async"
                          className="w-full h-full object-cover"
                          onError={handleImageError}
                        />
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <h4 className="text-xs sm:text-sm font-semibold text-stone-900 truncate">
                            {item.product.name}
                          </h4>
                          <button
                            onClick={() => onRemoveItem(item.id)}
                            className="text-stone-400 hover:text-rose-600 p-1 transition-colors"
                            title="Remove item"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>

                        <div className="text-[11px] text-stone-500 mt-0.5 space-y-0.5">
                          <div>
                            Size: <span className="font-medium text-stone-800">{item.size}</span>
                          </div>
                          {item.customColor && (
                            <div className="flex items-center gap-1.5 text-[10px] text-stone-700 bg-rose-50/70 px-1.5 py-0.5 rounded border border-rose-200 w-fit">
                              <span 
                                className="w-2.5 h-2.5 rounded-full border border-stone-300 shrink-0 shadow-2xs" 
                                style={{ backgroundColor: item.customColor.hex }} 
                              />
                              <span>Color: <strong className="text-stone-900">{item.customColor.name}</strong></span>
                              {item.customColor.neckline && <span className="text-stone-500">· {item.customColor.neckline}</span>}
                            </div>
                          )}
                          {item.customMeasurements && (
                            <div className="text-[10px] text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200 w-fit">
                              Custom: L: {item.customMeasurements.shirtLength}, C: {item.customMeasurements.chest}
                            </div>
                          )}
                        </div>

                        <div className="flex items-center justify-between mt-3">
                          {/* Quantity control */}
                          <div className="flex items-center border border-stone-200 rounded-md bg-stone-50">
                            <button
                              onClick={() => onUpdateQuantity(item.id, -1)}
                              className="p-1 text-stone-600 hover:text-stone-900 transition-colors"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-2 text-xs font-semibold tabular-nums text-stone-800">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => onUpdateQuantity(item.id, 1)}
                              className="p-1 text-stone-600 hover:text-stone-900 transition-colors"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          <div className="text-xs sm:text-sm font-bold text-stone-900 tabular-nums">
                            {formatPrice(item.pricePKR * item.quantity, currency)}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Coupon Form */}
              {items.length > 0 && (
                <div className="pt-2">
                  <form onSubmit={handleApplyCoupon} className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Coupon Code (e.g. HAYA10)"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      className="flex-1 px-3 py-2 text-xs border border-stone-300 rounded-lg uppercase"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                    >
                      Apply
                    </button>
                  </form>
                  {couponMessage && (
                    <div className="text-[11px] mt-1.5 text-stone-600 font-medium">
                      {couponMessage}
                    </div>
                  )}
                </div>
              )}
            </>
          )}

          {/* STEP 2: CHECKOUT FORM */}
          {step === 'checkout' && (
            <form id="checkout-form" onSubmit={handleCheckoutSubmit} className="space-y-4 text-xs">
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-stone-700 space-y-1">
                <div className="font-semibold text-stone-900">Cash on Delivery Available Across Pakistan</div>
                <div className="text-[11px] text-stone-500">
                  Pay at your doorstep upon receiving your parcel. We verify all orders via WhatsApp before dispatch.
                </div>
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Fatima Zahra"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-700 font-medium mb-1">WhatsApp / Phone Number *</label>
                  <input
                    type="tel"
                    required
                    placeholder="0321-XXXXXXX"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Email Address</label>
                  <input
                    type="email"
                    placeholder="Optional"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">Complete Delivery Address *</label>
                <textarea
                  required
                  rows={2}
                  placeholder="House/Apartment #, Street, Sector / Area"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-stone-700 font-medium mb-1">City *</label>
                  <select
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs bg-white"
                  >
                    {CITIES.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-stone-700 font-medium mb-1">Postal Code (Optional)</label>
                  <input
                    type="text"
                    placeholder="e.g. 75500"
                    value={formData.postalCode}
                    onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs"
                  />
                </div>
              </div>

              {/* Payment Method Selector */}
              <div>
                <label className="block text-stone-700 font-medium mb-1.5">Payment Method</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, paymentMethod: 'cod' })}
                    className={`p-2.5 rounded-lg border text-left transition-all cursor-pointer ${
                      formData.paymentMethod === 'cod'
                        ? 'border-stone-900 bg-stone-900 text-stone-50 font-semibold'
                        : 'border-stone-200 bg-white text-stone-700 hover:border-stone-300'
                    }`}
                  >
                    <div className="text-[11px]">Cash on Delivery</div>
                    <div className="text-[9px] opacity-80">Pay on parcel delivery</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, paymentMethod: 'bank_transfer' })}
                    className={`p-2.5 rounded-lg border text-left transition-all cursor-pointer ${
                      formData.paymentMethod === 'bank_transfer'
                        ? 'border-stone-900 bg-stone-900 text-stone-50 font-semibold'
                        : 'border-stone-200 bg-white text-stone-700 hover:border-stone-300'
                    }`}
                  >
                    <div className="text-[11px]">Bank Transfer</div>
                    <div className="text-[9px] opacity-80">Meezan / EasyPaisa</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, paymentMethod: 'card' })}
                    className={`p-2.5 rounded-lg border text-left transition-all cursor-pointer ${
                      formData.paymentMethod === 'card'
                        ? 'border-stone-900 bg-stone-900 text-stone-50 font-semibold'
                        : 'border-stone-200 bg-white text-stone-700 hover:border-stone-300'
                    }`}
                  >
                    <div className="text-[11px]">Card Payment</div>
                    <div className="text-[9px] opacity-80">Overseas / Debit / Visa</div>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-stone-700 font-medium mb-1">Order Notes (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. Leave with security guard, custom sleeve length"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs"
                />
              </div>
            </form>
          )}

          {/* STEP 3: ORDER CONFIRMED */}
          {step === 'confirmed' && placedOrder && (
            <div className="py-6 text-center space-y-4">
              <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto">
                <Check className="w-8 h-8" />
              </div>

              <div>
                <h3 className="font-serif text-2xl font-bold text-stone-900">
                  Shukriya! Order #{placedOrder.orderId} Confirmed
                </h3>
                <p className="text-xs text-stone-600 mt-1 max-w-sm mx-auto">
                  Thank you for shopping with <strong className="text-stone-900">Haya-e-Hayat</strong>. Our Karachi stitching & dispatch atelier is preparing your parcel.
                </p>
              </div>

              <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 text-left text-xs space-y-2 max-w-sm mx-auto">
                <div className="flex justify-between font-semibold text-stone-900 border-b border-stone-200 pb-1.5">
                  <span>Order Summary</span>
                  <span>{placedOrder.date}</span>
                </div>
                <div className="space-y-1">
                  {placedOrder.items.map((it, idx) => (
                    <div key={idx} className="flex justify-between text-stone-600">
                      <span>{it.quantity}x {it.product.name} ({it.size})</span>
                      <span className="font-medium text-stone-800 tabular-nums">Rs. {it.pricePKR * it.quantity}</span>
                    </div>
                  ))}
                </div>
                <div className="border-t border-stone-200 pt-1.5 flex justify-between font-bold text-stone-900">
                  <span>Total Payable:</span>
                  <span className="tabular-nums">Rs. {placedOrder.totalPKR}</span>
                </div>
                <div className="text-[11px] text-stone-500 pt-1">
                  Delivery to: {placedOrder.customer.fullName}, {placedOrder.customer.city}
                </div>
              </div>

              {/* Direct WhatsApp & Instagram Order Confirmation Buttons */}
              <div className="pt-2 space-y-2">
                <button
                  onClick={handleInstagramConfirm}
                  className="w-full py-3 px-4 bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#FCB045] hover:opacity-95 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 shadow-xs transition-opacity cursor-pointer"
                >
                  <Instagram className="w-4 h-4" />
                  <span>DM Order to Instagram (@hayaehayat)</span>
                </button>

                <button
                  onClick={handleWhatsAppConfirm}
                  className="w-full py-2.5 px-4 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Send Confirmation to WhatsApp (+92 321 4292328)</span>
                </button>

                <button
                  onClick={() => {
                    setStep('cart');
                    onClose();
                  }}
                  className="w-full py-2.5 px-4 border border-stone-300 hover:bg-stone-50 text-stone-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                >
                  Continue Shopping
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer Order Summary & Actions */}
        {step !== 'confirmed' && items.length > 0 && (
          <div className="p-4 sm:p-5 border-t border-stone-200 bg-[#FAF9F6] space-y-3">
            <div className="space-y-1 text-xs">
              <div className="flex justify-between text-stone-600">
                <span>Subtotal</span>
                <span className="tabular-nums font-medium">{formatPrice(subtotalPKR, currency)}</span>
              </div>
              {discountPKR > 0 && (
                <div className="flex justify-between text-emerald-700 font-medium">
                  <span>Welcome Discount ({discountPercent}%)</span>
                  <span className="tabular-nums">-{formatPrice(discountPKR, currency)}</span>
                </div>
              )}
              <div className="flex justify-between text-stone-600">
                <span>Shipping ({formData.city || 'All Over Pakistan'})</span>
                <span className="tabular-nums font-semibold text-emerald-700">
                  FREE (All Pakistan)
                </span>
              </div>
              <div className="flex justify-between text-sm sm:text-base font-bold text-stone-900 border-t border-stone-200 pt-2">
                <span>Total</span>
                <span className="tabular-nums">{formatPrice(totalPKR, currency)}</span>
              </div>
            </div>

            {step === 'cart' ? (
              <div className="space-y-2">
                <button
                  onClick={() => setStep('checkout')}
                  className="w-full py-3.5 px-4 bg-stone-900 hover:bg-stone-800 text-stone-50 text-xs sm:text-sm font-semibold rounded-xl flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
                >
                  <span>Proceed to Cash on Delivery</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={handleInstagramDirectOrder}
                  className="w-full py-2.5 px-4 bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#FCB045] hover:opacity-95 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 shadow-xs transition-opacity cursor-pointer"
                  title="DM bag details to Instagram @hayaehayat"
                >
                  <Instagram className="w-4 h-4 text-white" />
                  <span>
                    {copiedCartForIg ? 'Bag Copied! Opening @hayaehayat DM...' : 'DM Bag to Instagram for Order'}
                  </span>
                </button>
              </div>
            ) : (
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setStep('cart')}
                  className="px-4 py-3 border border-stone-300 bg-white text-stone-700 rounded-xl text-xs font-semibold hover:bg-stone-50 transition-colors"
                >
                  Back to Bag
                </button>
                <button
                  type="submit"
                  form="checkout-form"
                  className="flex-1 py-3 px-4 bg-stone-900 hover:bg-stone-800 text-stone-50 text-xs sm:text-sm font-semibold rounded-xl flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
                >
                  <span>Place Order (Pay on Delivery)</span>
                  <Truck className="w-4 h-4" />
                </button>
              </div>
            )}

            <div className="flex items-center justify-center gap-2 text-[11px] text-stone-500">
              <ShieldCheck className="w-3.5 h-3.5 text-stone-400" />
              <span>Safe & Secure Checkout · 7-Day Hassle-Free Returns</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
