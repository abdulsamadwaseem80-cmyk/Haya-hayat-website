import React, { useState, useEffect, useMemo } from 'react';
import { AnnouncementBar } from './components/AnnouncementBar';
import { Header } from './components/Header';
import { CategoryNavStrip } from './components/CategoryNavStrip';
import { HeroSection } from './components/HeroSection';
import { CategoryGrid } from './components/CategoryGrid';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { SizeGuideModal } from './components/SizeGuideModal';
import { AboutUsModal } from './components/AboutUsModal';
import { CartDrawer } from './components/CartDrawer';
import { WishlistDrawer } from './components/WishlistDrawer';
import { SearchModal } from './components/SearchModal';
import { InstagramFeed } from './components/InstagramFeed';
import { AtelierSection } from './components/AtelierSection';
import { Footer } from './components/Footer';
import { CustomColorModal } from './components/CustomColorModal';

import { PRODUCTS, Product, INSTAGRAM_ORDER_URL, CORDSET_CUSTOM_COLORS } from './data/products';
import { CartItem, Currency } from './types';
import { Truck, RefreshCw, ShieldCheck, Headphones, Scissors, Sparkles, Check, Instagram, Palette } from 'lucide-react';

export default function App() {
  const [currency, setCurrency] = useState<Currency>('PKR');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'all' | 'bestseller' | 'new' | 'university' | 'budget'>('all');
  const [fabricFilter, setFabricFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');

  // Modal States
  const [isAboutUsOpen, setIsAboutUsOpen] = useState<boolean>(false);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState<boolean>(false);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState<boolean>(false);
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [isCustomColorModalOpen, setIsCustomColorModalOpen] = useState<boolean>(false);
  const [customColorProduct, setCustomColorProduct] = useState<Product | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const handleOpenCustomColorStudio = (prod?: Product) => {
    const target = prod || PRODUCTS.find((p) => p.id === 'hh-solid-plum') || PRODUCTS[0];
    setCustomColorProduct(target);
    setIsCustomColorModalOpen(true);
  };

  // Notification Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2500);
  };

  // Cart State with LocalStorage
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('hh_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('hh_cart', JSON.stringify(cartItems));
    } catch {
      // ignore
    }
  }, [cartItems]);

  // Wishlist State with LocalStorage
  const [wishlist, setWishlist] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('hh_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('hh_wishlist', JSON.stringify(wishlist));
    } catch {
      // ignore
    }
  }, [wishlist]);

  // Cart operations
  const handleAddToCart = (
    product: Product,
    size: 'XS' | 'S' | 'M' | 'L' | 'XL' | 'Custom' = 'M',
    customMeasurements?: {
      shirtLength?: string;
      chest?: string;
      trouserLength?: string;
      additionalNote?: string;
    },
    customColor?: {
      name: string;
      hex: string;
      neckline?: string;
      shirtLength?: string;
      trouserStyle?: string;
      isCustomToned?: boolean;
    }
  ) => {
    setCartItems((prev) => {
      // If same product, same size, same custom specs and same custom color, increment quantity
      const existingIdx = prev.findIndex(
        (it) =>
          it.productId === product.id &&
          it.size === size &&
          JSON.stringify(it.customMeasurements) === JSON.stringify(customMeasurements) &&
          JSON.stringify(it.customColor) === JSON.stringify(customColor)
      );

      if (existingIdx > -1) {
        const next = [...prev];
        next[existingIdx].quantity += 1;
        return next;
      }

      const colorId = customColor ? `-${customColor.name.toLowerCase().replace(/\s+/g, '-')}` : '';
      const newItem: CartItem = {
        id: `${product.id}-${size}${colorId}-${Date.now()}`,
        productId: product.id,
        product,
        size,
        customColor,
        customMeasurements,
        quantity: 1,
        pricePKR: product.pricePKR,
      };
      return [...prev, newItem];
    });

    const colorLabel = customColor ? ` in ${customColor.name}` : '';
    showToast(`Added "${product.name}"${colorLabel} (${size}) to your bag!`);
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((it) => {
          if (it.id === id) {
            const newQty = it.quantity + delta;
            return newQty > 0 ? { ...it, quantity: newQty } : null;
          }
          return it;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveItem = (id: string) => {
    setCartItems((prev) => prev.filter((it) => it.id !== id));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Wishlist toggle
  const handleToggleWishlist = (product: Product) => {
    setWishlist((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      if (exists) {
        showToast(`Removed from favorites.`);
        return prev.filter((p) => p.id !== product.id);
      } else {
        showToast(`Saved "${product.name}" to favorites!`);
        return [...prev, product];
      }
    });
  };

  const isProductWishlisted = (productId: string) => {
    return wishlist.some((p) => p.id === productId);
  };

  // Filtered & Sorted Products
  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((item) => {
      // Category filter
      if (activeCategory !== 'all' && item.category !== activeCategory) {
        return false;
      }

      // Tab filter
      if (activeTab === 'bestseller' && !item.isBestSeller) return false;
      if (activeTab === 'new' && !item.isNewArrival) return false;
      if (activeTab === 'university' && !item.isUniversityFavorite) return false;
      if (activeTab === 'budget' && item.pricePKR > 3500) return false;

      // Fabric filter
      if (fabricFilter !== 'all') {
        if (!item.fabric.toLowerCase().includes(fabricFilter.toLowerCase())) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.pricePKR - b.pricePKR;
      if (sortBy === 'price-desc') return b.pricePKR - a.pricePKR;
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0; // featured default
    });
  }, [activeCategory, activeTab, fabricFilter, sortBy]);

  const totalCartCount = cartItems.reduce((acc, it) => acc + it.quantity, 0);

  const scrollToCatalog = () => {
    const el = document.getElementById('catalog');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF9F6] text-stone-900 selection:bg-[#E8DCC4]">
      {/* Toast Banner */}
      {toastMessage && (
        <div className="fixed top-20 right-4 sm:right-6 z-50 bg-stone-900 text-stone-50 px-4 py-2.5 rounded-xl shadow-xl flex items-center gap-2 text-xs font-medium border border-stone-700 animate-in fade-in slide-in-from-top-2">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Announcement Bar */}
      <AnnouncementBar
        currency={currency}
        onCurrencyChange={setCurrency}
        onOpenSizeGuide={() => setIsSizeGuideOpen(true)}
        onOpenCustomColorStudio={() => handleOpenCustomColorStudio()}
      />

      {/* Primary Sticky Header (Top Bar Contract: Brand, Nav, Actions) */}
      <Header
        cartCount={totalCartCount}
        wishlistCount={wishlist.length}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenAboutUs={() => setIsAboutUsOpen(true)}
        onOpenCustomColorStudio={() => handleOpenCustomColorStudio()}
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
          scrollToCatalog();
        }}
        activeCategory={activeCategory}
      />

      {/* Category Quick Navigation Strip */}
      <CategoryNavStrip
        activeCategory={activeCategory}
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
          scrollToCatalog();
        }}
        onOpenSizeGuide={() => setIsSizeGuideOpen(true)}
      />

      {/* Hero Showcase Section */}
      <HeroSection
        onShopClick={scrollToCatalog}
        onOpenCustomSizing={() => setIsSizeGuideOpen(true)}
        onOpenCustomColorStudio={() => handleOpenCustomColorStudio()}
      />

      {/* 4 Curated Category Tiles */}
      <CategoryGrid
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
          scrollToCatalog();
        }}
      />

      {/* Main Catalog & Trending Products Section */}
      <main id="catalog" className="py-12 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6 w-full">
        {/* Section Header with Tabs */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-6 border-b border-stone-200 pb-6">
          <div>
            <div className="text-xs font-semibold tracking-widest uppercase text-stone-500 mb-1">
              {activeCategory === 'all'
                ? 'Ready-to-Wear Catalog'
                : PRODUCTS.find((p) => p.category === activeCategory)?.categoryLabel || 'Collection'}
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl font-medium text-stone-900">
              Trending & Signature Designs
            </h2>
            <p className="text-xs sm:text-sm text-stone-600 mt-1">
              Showing <span className="font-semibold text-stone-900">{filteredProducts.length}</span> curated modest wear outfits
            </p>
          </div>

          {/* Filter Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-stone-100 rounded-xl border border-stone-200/80">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'all'
                  ? 'bg-white text-stone-900 shadow-xs font-semibold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              All Items
            </button>
            <button
              onClick={() => setActiveTab('bestseller')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'bestseller'
                  ? 'bg-white text-stone-900 shadow-xs font-semibold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Best Sellers
            </button>
            <button
              onClick={() => setActiveTab('new')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'new'
                  ? 'bg-white text-stone-900 shadow-xs font-semibold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              New Season
            </button>
            <button
              onClick={() => setActiveTab('university')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'university'
                  ? 'bg-white text-stone-900 shadow-xs font-semibold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              University Edit
            </button>
            <button
              onClick={() => setActiveTab('budget')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                activeTab === 'budget'
                  ? 'bg-white text-stone-900 shadow-xs font-semibold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Under Rs. 3,500
            </button>
          </div>
        </div>

        {/* Secondary Filters & Sort Controls */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8 text-xs text-stone-600">
          {/* Fabric filter */}
          <div className="flex items-center gap-2">
            <span className="font-medium text-stone-500">Fabric:</span>
            <div className="flex flex-wrap gap-1">
              {[
                { id: 'all', label: 'All Fabrics' },
                { id: 'linen', label: 'Linen' },
                { id: 'cotton', label: 'Cotton' },
                { id: 'cambric', label: 'Cambric' },
                { id: 'silk', label: 'Raw Silk' },
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => setFabricFilter(f.id)}
                  className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                    fabricFilter === f.id
                      ? 'bg-stone-800 text-stone-100 font-semibold'
                      : 'bg-white border border-stone-200 text-stone-600 hover:border-stone-400'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* Sort selector */}
          <div className="flex items-center gap-2">
            <span className="font-medium text-stone-500">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-white border border-stone-200 rounded-lg px-2.5 py-1.5 text-xs text-stone-800 cursor-pointer outline-none"
            >
              <option value="featured">Featured Collection</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Top Customer Ratings</option>
            </select>
          </div>
        </div>

        {/* Interactive "Customize in Your Favorite Color" Showcase Banner */}
        <div className="mb-8 p-5 sm:p-6 rounded-2xl bg-gradient-to-r from-[#FBF8F3] via-[#FAF5EE] to-[#F7EFE9] border border-amber-200/90 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-100/90 text-rose-950 text-xs font-bold tracking-wide">
              <Sparkles className="w-3.5 h-3.5 text-rose-600" />
              <span>customize in your favorite color✨🫶🏻</span>
            </div>
            <h3 className="font-serif text-xl sm:text-2xl font-semibold text-stone-900 leading-tight">
              Solid 2-Piece, Affordable Workwear, University Girl Outfit
            </h3>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
              Modest flowy A-line flare with hand-embellished double-row pearl neckline & wide-leg palazzo trousers. Tailored in wrinkle-resistant crepe silk blend in Karachi.
            </p>

            {/* Color preview dots */}
            <div className="flex items-center gap-2 pt-1 flex-wrap">
              <span className="text-xs font-semibold text-stone-700">Trending Colors:</span>
              {CORDSET_CUSTOM_COLORS.slice(0, 8).map((col) => (
                <button
                  key={col.name}
                  onClick={() => handleOpenCustomColorStudio()}
                  title={`Customize in ${col.name}`}
                  className="w-5 h-5 rounded-full border border-white shadow-2xs hover:scale-125 transition-transform cursor-pointer"
                  style={{ backgroundColor: col.hex }}
                />
              ))}
              <button
                onClick={() => handleOpenCustomColorStudio()}
                className="text-[11px] text-rose-700 hover:text-rose-900 font-semibold underline ml-1 cursor-pointer"
              >
                + Choose from 12+ or Custom Dye
              </button>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-2.5 w-full md:w-auto shrink-0">
            <button
              onClick={() => handleOpenCustomColorStudio()}
              className="px-5 py-3 bg-stone-900 hover:bg-stone-800 text-stone-50 text-xs font-semibold rounded-xl shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Palette className="w-4 h-4 text-amber-300" />
              <span>Launch Color Studio ✨</span>
            </button>

            <a
              href="https://www.instagram.com/hayaehayat?stkn=MXIwZHJsNngzdWpwYQ=="
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-3 bg-pink-50 hover:bg-pink-100 text-pink-800 border border-pink-200/90 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Instagram className="w-4 h-4 text-pink-600" />
              <span>DM Color on IG</span>
            </a>
          </div>
        </div>

        {/* Product Grid */}
        {filteredProducts.length === 0 ? (
          <div className="py-16 text-center space-y-3 bg-white rounded-2xl border border-stone-200 p-8">
            <p className="text-stone-600 text-sm">No items found matching the selected filters.</p>
            <button
              onClick={() => {
                setActiveCategory('all');
                setActiveTab('all');
                setFabricFilter('all');
              }}
              className="px-4 py-2 bg-stone-900 text-stone-50 rounded-lg text-xs font-semibold hover:bg-stone-800 transition-colors"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                currency={currency}
                isWishlisted={isProductWishlisted(product.id)}
                onToggleWishlist={handleToggleWishlist}
                onQuickView={(p) => setSelectedProduct(p)}
                onAddToCart={(p, sz, meas, col) => handleAddToCart(p, sz, meas, col)}
                onOpenCustomColorStudio={handleOpenCustomColorStudio}
              />
            ))}
          </div>
        )}
      </main>

      {/* Trust Badges Strip (Inspired by user's reference) */}
      <section className="bg-white border-y border-stone-200 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-800 flex items-center justify-center shrink-0">
                <Truck className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-serif font-bold text-stone-900 text-sm">Free Delivery in All Over Pakistan</h4>
                <p className="text-xs text-stone-500 mt-0.5">100% Free shipping on all orders nationwide · COD</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-800 flex items-center justify-center shrink-0">
                <RefreshCw className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-serif font-bold text-stone-900 text-sm">7-Day Easy Exchange</h4>
                <p className="text-xs text-stone-500 mt-0.5">Hassle-free size replacement</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-sky-50 text-sky-800 flex items-center justify-center shrink-0">
                <Scissors className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-serif font-bold text-stone-900 text-sm">Custom Sizing Support</h4>
                <p className="text-xs text-stone-500 mt-0.5">Tailored lengths via Karachi atelier</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-purple-50 text-purple-800 flex items-center justify-center shrink-0">
                <Headphones className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-serif font-bold text-stone-900 text-sm">WhatsApp Concierge</h4>
                <p className="text-xs text-stone-500 mt-0.5">+92 321 4292328 fast response</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Secondary Promo Banner: Made-to-Measure Experience */}
      <section className="py-14 sm:py-20 bg-gradient-to-r from-[#F0ECE1] via-[#FAF7F2] to-[#EFEAE0] border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-8 space-y-4">
              <span className="text-xs font-semibold uppercase tracking-widest text-amber-800">
                Atelier Specialty
              </span>
              <h3 className="font-serif text-3xl sm:text-4xl font-medium text-stone-900 leading-tight">
                Every Silhouette Deserves a Flawless, Modest Fit
              </h3>
              <p className="text-stone-600 text-sm sm:text-base leading-relaxed max-w-2xl">
                Have trouble finding the right shirt length or comfortable trouser waist in standard retail sizes? At Haya-e-Hayat, our in-house Karachi tailoring unit customizes lengths, cuts, and sleeves for you at no added hassle.
              </p>
              <div className="pt-2 flex flex-wrap gap-3">
                <button
                  onClick={() => setIsSizeGuideOpen(true)}
                  className="px-5 py-3 bg-stone-900 hover:bg-stone-800 text-stone-50 rounded-xl text-xs font-semibold shadow-sm transition-colors cursor-pointer"
                >
                  Open Custom Sizing Guide
                </button>
                <a
                  href="https://wa.me/923214292328?text=Assalam%20o%20Alaikum%20Haya-e-Hayat!%20I%20would%20like%20to%20inquire%20about%20custom%20stitching"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors"
                >
                  Consult Master Tailor on WhatsApp
                </a>
              </div>
            </div>

            <div className="lg:col-span-4 bg-white/90 backdrop-blur-md rounded-2xl p-6 border border-stone-300 shadow-sm space-y-3 text-xs">
              <div className="flex items-center gap-2 font-bold text-stone-900">
                <Sparkles className="w-4 h-4 text-amber-700" />
                <span>Quick Custom Measurement Specs</span>
              </div>
              <ul className="space-y-2 text-stone-600">
                <li className="flex items-center justify-between border-b border-stone-100 pb-1">
                  <span>Custom Shirt Length:</span>
                  <span className="font-semibold text-stone-900">36" to 46" Available</span>
                </li>
                <li className="flex items-center justify-between border-b border-stone-100 pb-1">
                  <span>Custom Trouser Inseam:</span>
                  <span className="font-semibold text-stone-900">35" to 42" Available</span>
                </li>
                <li className="flex items-center justify-between border-b border-stone-100 pb-1">
                  <span>Sleeve Cuff Style:</span>
                  <span className="font-semibold text-stone-900">Cutwork / Plain / Bell</span>
                </li>
                <li className="flex items-center justify-between">
                  <span>Stitching Lead Time:</span>
                  <span className="font-semibold text-emerald-700">2-3 Working Days</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Shoppable Instagram Feed (@hayaehayat) */}
      <InstagramFeed onShopCollection={scrollToCatalog} />

      {/* Atelier Story, Google Business Profile & Karachi Logistics */}
      <AtelierSection />

      {/* Footer with Links, Contact & Copyright */}
      <Footer
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
          scrollToCatalog();
        }}
        onOpenSizeGuide={() => setIsSizeGuideOpen(true)}
        onOpenAboutUs={() => setIsAboutUsOpen(true)}
      />

      {/* Modals & Drawers */}
      <ProductDetailModal
        product={selectedProduct}
        currency={currency}
        isWishlisted={selectedProduct ? isProductWishlisted(selectedProduct.id) : false}
        onClose={() => setSelectedProduct(null)}
        onToggleWishlist={handleToggleWishlist}
        onAddToCart={handleAddToCart}
        onOpenSizeGuide={() => setIsSizeGuideOpen(true)}
        onOpenCustomColorStudio={handleOpenCustomColorStudio}
      />

      <CustomColorModal
        isOpen={isCustomColorModalOpen}
        onClose={() => setIsCustomColorModalOpen(false)}
        product={customColorProduct || PRODUCTS[0]}
        currency={currency}
        onAddToCart={(p, sz, color, meas) => {
          handleAddToCart(p, sz, meas, color);
          setIsCustomColorModalOpen(false);
        }}
        onOpenSizeGuide={() => setIsSizeGuideOpen(true)}
      />

      <SizeGuideModal
        isOpen={isSizeGuideOpen}
        onClose={() => setIsSizeGuideOpen(false)}
      />

      <AboutUsModal
        isOpen={isAboutUsOpen}
        onClose={() => setIsAboutUsOpen(false)}
        onExploreCollection={scrollToCatalog}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        currency={currency}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlist={wishlist}
        currency={currency}
        onRemoveFromWishlist={(id) => {
          setWishlist((prev) => prev.filter((p) => p.id !== id));
        }}
        onAddToCart={(product) => handleAddToCart(product, 'M')}
      />

      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        currency={currency}
        onSelectProduct={(product) => setSelectedProduct(product)}
      />

      {/* Floating Action Buttons: Customize Color + Instagram DM */}
      <aside aria-label="Direct actions" className="fixed bottom-5 right-5 z-40 flex flex-col sm:flex-row items-end sm:items-center gap-2">
        <button
          onClick={() => handleOpenCustomColorStudio()}
          className="flex items-center gap-2 px-3.5 py-2.5 bg-stone-900 hover:bg-stone-800 text-stone-50 font-semibold text-xs rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-0.5 cursor-pointer border border-stone-700 backdrop-blur-xs"
          title="Customize 2-piece cordsets in your favorite color"
        >
          <Palette className="w-3.5 h-3.5 text-amber-300" />
          <span>Customize Color ✨</span>
        </button>

        <a
          href={INSTAGRAM_ORDER_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="group flex items-center gap-2.5 px-4 py-2.5 bg-gradient-to-r from-[#833AB4] via-[#FD1D1D] to-[#FCB045] hover:opacity-95 text-white font-semibold text-xs rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-0.5 cursor-pointer border border-white/30 backdrop-blur-xs"
          title="DM on Instagram for Orders: @hayaehayat"
        >
          <Instagram className="w-4 h-4 text-white animate-pulse shrink-0" />
          <span className="hidden sm:inline">DM on Instagram</span>
          <span className="sm:hidden">DM</span>
          <span className="px-1.5 py-0.5 bg-white/20 rounded-full text-[10px] tracking-wide">
            @hayaehayat
          </span>
        </a>
      </aside>
    </div>
  );
}
