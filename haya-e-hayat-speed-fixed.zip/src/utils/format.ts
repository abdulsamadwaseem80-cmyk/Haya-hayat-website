import { Currency } from '../types';

export const PKR_TO_USD_RATE = 0.0036; // ~ Rs. 280 = $1

export function formatPrice(pricePKR: number, currency: Currency): string {
  if (currency === 'USD') {
    const usd = (pricePKR * PKR_TO_USD_RATE).toFixed(2);
    return `$${usd}`;
  }
  return `Rs. ${pricePKR.toLocaleString('en-PK')}`;
}
