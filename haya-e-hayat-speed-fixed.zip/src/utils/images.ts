import type { SyntheticEvent } from 'react';

/**
 * Working placeholder shown if any image ever fails to load.
 * (picsum.photos is a reliable free placeholder service.)
 */
export const PLACEHOLDER_IMAGE = 'https://picsum.photos/800/1000';

/**
 * Vite bundles every image inside src/assets/images and gives us its final
 * (hashed) production URL. Plain strings like '/src/assets/images/x.jpg'
 * only work in `vite dev` - they 404 after `vite build` (e.g. on Vercel).
 */
const bundledImages = import.meta.glob('/src/assets/images/*.{jpg,jpeg,png,webp,avif,gif,svg}', {
  eager: true,
  query: '?url',
  import: 'default',
}) as Record<string, string>;

/**
 * Turns '/src/assets/images/pic.jpg' into the real bundled URL.
 * Falls back to a placeholder if the file does not exist.
 */
export const resolveImage = (path: string): string => {
  if (/^(https?:)?\/\//.test(path) || path.startsWith('data:')) return path;
  return bundledImages[path] ?? PLACEHOLDER_IMAGE;
};

/**
 * Use as <img onError={handleImageError} /> - swaps a broken image for the
 * placeholder (only once, so it can never loop).
 */
export const handleImageError = (e: SyntheticEvent<HTMLImageElement>) => {
  const img = e.currentTarget;
  if (img.dataset.fallbackApplied === 'true') return;
  img.dataset.fallbackApplied = 'true';
  img.src = PLACEHOLDER_IMAGE;
};
