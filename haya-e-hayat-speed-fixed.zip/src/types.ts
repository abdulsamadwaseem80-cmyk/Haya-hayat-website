import { Product } from './data/products';

export type Currency = 'PKR' | 'USD';

export interface CartItem {
  id: string; // unique item instance id
  productId: string;
  product: Product;
  size: 'XS' | 'S' | 'M' | 'L' | 'XL' | 'Custom';
  customColor?: {
    name: string;
    hex: string;
    neckline?: string;
    shirtLength?: string;
    trouserStyle?: string;
    isCustomToned?: boolean;
  };
  customMeasurements?: {
    shirtLength?: string;
    chest?: string;
    trouserLength?: string;
    additionalNote?: string;
  };
  quantity: number;
  pricePKR: number;
}

export interface CheckoutFormState {
  fullName: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  postalCode: string;
  paymentMethod: 'cod' | 'bank_transfer' | 'card';
  notes: string;
}

export interface PlacedOrder {
  orderId: string;
  items: CartItem[];
  subtotalPKR: number;
  discountPKR: number;
  shippingPKR: number;
  totalPKR: number;
  customer: CheckoutFormState;
  date: string;
}
